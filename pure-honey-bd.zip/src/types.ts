/**
 * Types for Pure Honey BD ecommerce landing page.
 */

export interface HoneyWeightOption {
  weight: string; // e.g., '250g', '500g', '1kg'
  price: number;  // original price
  discountPrice?: number; // active price under offer
}

export interface Product {
  id: string;
  name: string;
  englishName: string;
  shortDescription: string;
  longDescription: string;
  defaultPrice: number;
  originalPrice: number;
  rating: number;
  reviewCount: number;
  image: string;
  bannerImage?: string;
  benefits: string[];
  scientificName?: string;
  harvestArea: string;
  tasteProfile: string;
  weightOptions: HoneyWeightOption[];
  color: string; // e.g., 'Golden Amber', 'Deep Dark', 'Light Yellow'
  stockStatus: 'In Stock' | 'Limited Stock' | 'Out of Stock';
  bestFor: string;
}

export interface CartItem {
  product: Product;
  selectedWeight: string;
  selectedPrice: number;
  quantity: number;
}

export enum PaymentMethod {
  COD = "Cash On Delivery",
  bkash = "bKash",
  Nagad = "Nagad",
  Rocket = "Rocket"
}

export interface OrderInput {
  customerName: string;
  phone: string;
  address: string;
  productId: string;
  productName: string;
  weight: string;
  quantity: number;
  totalPrice: number;
  paymentMethod: PaymentMethod;
  paymentNumber?: string; // for bKash/Nagad/Rocket transaction account info
  transactionId?: string; // manual transaction verification
}

export interface OrderRecord extends OrderInput {
  id: string;
  status: 'Pending' | 'Shipped' | 'Completed' | 'Cancelled';
  date: string;
}

export interface Testimonial {
  id: string;
  name: string;
  location: string;
  rating: number;
  comment: string;
  avatar: string;
  verified: boolean;
  date: string;
  productBought: string;
}

export interface FAQItem {
  id: string;
  question: string;
  answer: string;
  category: string;
}
