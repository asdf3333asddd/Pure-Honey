import { useState, useEffect } from 'react';
import { Product, CartItem, OrderInput, OrderRecord } from './types';
import { PRODUCTS } from './data';

// Component imports
import AnnouncementBar from './components/AnnouncementBar';
import Navbar from './components/Navbar';
import HeroSection from './components/HeroSection';
import ProductSection from './components/ProductSection';
import ProductPopup from './components/ProductPopup';
import BenefitsSection from './components/BenefitsSection';
import StorySection from './components/StorySection';
import ReviewsSection from './components/ReviewsSection';
import CheckoutForm from './components/CheckoutForm';
import FAQSection from './components/FAQSection';
import AboutContactMap from './components/AboutContactMap';
import AdminPanel from './components/AdminPanel';
import Footer from './components/Footer';

// Icons
import { ShoppingBag, ArrowUp, X, MessageSquare, ShieldAlert, Check, ShoppingCart } from 'lucide-react';

export default function App() {
  // 1. Core State Managers
  const [cartItems, setCartItems] = useState<CartItem[]>([]);
  const [orders, setOrders] = useState<OrderRecord[]>([]);
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  
  // Custom Google Sheets connector state
  const [sheetUrl, setSheetUrl] = useState<string>('');

  // 2. Interface UI toggles
  const [isAdminOpen, setIsAdminOpen] = useState(false);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [showScrollTop, setShowScrollTop] = useState(false);

  // 3. Fake Live Purchase notification system
  const [fakeNotification, setFakeNotification] = useState<{
    buyer: string;
    location: string;
    product: string;
    qty: string;
    ago: string;
  } | null>(null);

  // Load configurations from standard localStorage on startup
  useEffect(() => {
    try {
      const savedCart = localStorage.getItem('ph_cart');
      if (savedCart) setCartItems(JSON.parse(savedCart));

      const savedOrders = localStorage.getItem('ph_orders');
      if (savedOrders) setOrders(JSON.parse(savedOrders));

      const savedUrl = localStorage.getItem('ph_sheet_url');
      if (savedUrl) setSheetUrl(savedUrl);
    } catch (e) {
      console.error("Error reading localStorage", e);
    }
  }, []);

  // Sync state helpers
  const saveCartToLocalStorage = (newCart: CartItem[]) => {
    setCartItems(newCart);
    localStorage.setItem('ph_cart', JSON.stringify(newCart));
  };

  // Back to top indicator
  useEffect(() => {
    const handleScroll = () => {
      setShowScrollTop(window.scrollY > 400);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Fake purchase loop (every 22 seconds to avoid over-cluttering)
  useEffect(() => {
    const buyers = [
      { name: "আরিফ বিল্লাহ", loc: "মিরপুর, ঢাকা", prod: "Sundarban Mangrove Honey", qty: "১ কেজি" },
      { name: "সায়মা রহমান", loc: "চট্টগ্রাম সদর", prod: "Kalojira Flower Honey", qty: "৫০০ গ্রাম" },
      { name: "মোঃ জাহিদ পাটোয়ারী", loc: "কুমিল্লা সদর", prod: "Pahari Wild Honey", qty: "২ কেজি" },
      { name: "ফাতেমা তুজ জোোহরা", loc: "উত্তরা, ঢাকা", prod: "Sorisha Flower Honey", qty: "১ কেজি" },
      { name: "ইশতিয়াক আহমেদ", loc: "সিলেট শাহজালাল", prod: "Litchi Flower Honey", qty: "৫০০ গ্রাম" },
      { name: "নাবিলা ইসলাম", loc: "রাজশাহী সদর", prod: "Mixed Flower Honey", qty: "২ কেজি" }
    ];

    const showNotification = () => {
      const randomIdx = Math.floor(Math.random() * buyers.length);
      const buyer = buyers[randomIdx];
      setFakeNotification({
        buyer: buyer.name,
        location: buyer.loc,
        product: buyer.prod,
        qty: buyer.qty,
        ago: `${Math.floor(Math.random() * 8) + 1} মিনিট আগে`
      });

      // Clear after 6 seconds
      setTimeout(() => {
        setFakeNotification(null);
      }, 6000);
    };

    // First triggered after 8 seconds
    const initialTimer = setTimeout(showNotification, 8000);

    const interval = setInterval(showNotification, 24000);
    return () => {
      clearTimeout(initialTimer);
      clearInterval(interval);
    };
  }, []);

  // Cart operations
  const handleAddToCart = (product: Product, weight: string, price: number, quantity: number) => {
    const existingIdx = cartItems.findIndex(
      item => item.product.id === product.id && item.selectedWeight === weight
    );

    let updatedCart = [...cartItems];
    if (existingIdx > -1) {
      updatedCart[existingIdx].quantity += quantity;
    } else {
      updatedCart.push({ product, selectedWeight: weight, selectedPrice: price, quantity });
    }
    saveCartToLocalStorage(updatedCart);
  };

  const handleRemoveFromCart = (index: number) => {
    let updatedCart = [...cartItems];
    updatedCart.splice(index, 1);
    saveCartToLocalStorage(updatedCart);
  };

  const handleClearCart = () => {
    saveCartToLocalStorage([]);
  };

  const handleDirectCheckout = (product: Product, weight: string, price: number, quantity: number) => {
    // Quick direct buy by overriding cart
    const item: CartItem = { product, selectedWeight: weight, selectedPrice: price, quantity };
    saveCartToLocalStorage([item]);
    
    // Smooth scroll to checkout form container
    const element = document.getElementById("checkout-section");
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  // 4. Submission handler - Performs sheet submission and state saving
  const handleSubmitOrder = async (order: OrderInput): Promise<{ success: boolean; orderId?: string; error?: string }> => {
    const orderId = `PHB-${Math.floor(100000 + Math.random() * 900000)}`;
    const newRecord: OrderRecord = {
      ...order,
      id: orderId,
      status: 'Pending',
      date: new Date().toLocaleString('en-US', { timeZone: 'Asia/Dhaka' })
    };

    // Update local sellers table list
    const updatedOrders = [newRecord, ...orders];
    setOrders(updatedOrders);
    localStorage.setItem('ph_orders', JSON.stringify(updatedOrders));

    // Send payload directly to external Google sheet Web App URL if saved
    if (sheetUrl && sheetUrl.trim().startsWith('http')) {
      try {
        const response = await fetch(sheetUrl, {
          method: 'POST',
          mode: 'no-cors', // standard block-free cors override for Apps script responses
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({
            orderId: newRecord.id,
            customerName: newRecord.customerName,
            phone: newRecord.phone,
            address: newRecord.address,
            productName: newRecord.productName,
            totalPrice: newRecord.totalPrice,
            paymentMethod: newRecord.paymentMethod,
            paymentNumber: newRecord.paymentNumber,
            transactionId: newRecord.transactionId
          })
        });
        
        // Return successful since Apps script POST was initiated (no-cors mode returns opaque/blank result)
        return { success: true, orderId };
      } catch (err: any) {
        console.error("Error pushing order to Google Apps Script Web App", err);
        // We still consider it successful locally to offer bullet-proof demo testing experience
        return { success: true, orderId };
      }
    }

    return { success: true, orderId };
  };

  const handleSaveSheetUrl = (url: string) => {
    setSheetUrl(url);
    localStorage.setItem('ph_sheet_url', url);
  };

  const handleClearOrders = () => {
    setOrders([]);
    localStorage.removeItem('ph_orders');
  };

  const handleScrollToDiv = (idStr: string) => {
    const el = document.querySelector(idStr);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handleQuickAddPredefinedProduct = (prodId: string) => {
    const prod = PRODUCTS.find(p => p.id === prodId);
    if (prod) {
      handleAddToCart(prod, prod.weightOptions[1].weight, prod.weightOptions[1].discountPrice || prod.weightOptions[1].price, 1);
    }
  };

  return (
    <div className="font-sans antialiased text-[#1E1E1E]">
      
      {/* 1. Slim announcement bar */}
      <AnnouncementBar onOpenAdmin={() => setIsAdminOpen(true)} orderCount={orders.length} />

      {/* 2. Sticky premium navigation */}
      <Navbar 
        onOpenCart={() => setIsCartOpen(true)} 
        cartItems={cartItems} 
        cartCount={cartItems.reduce((acc, item) => acc + item.quantity, 0)} 
      />

      {/* 3. Cinematic hero section */}
      <HeroSection 
        onOrderNow={() => handleScrollToDiv('#checkout-section')} 
        onViewProducts={() => handleScrollToDiv('#products')} 
      />

      {/* 4. Honey product variant display */}
      <ProductSection 
        onAddToCart={handleAddToCart}
        onSelectProduct={(p) => setSelectedProduct(p)}
        onDirectCheckout={handleDirectCheckout}
      />

      {/* 5. Clean natural benefits summary honeycomb */}
      <BenefitsSection />

      {/* 6. Video story timeline section */}
      <StorySection />

      {/* 7. Sliding customer testemonials list */}
      <ReviewsSection />

      {/* 8. Conversion Checkout order forms */}
      <CheckoutForm 
        cartItems={cartItems}
        onRemoveFromCart={handleRemoveFromCart}
        onClearCart={handleClearCart}
        onSubmitOrder={handleSubmitOrder}
        sheetUrl={sheetUrl}
      />

      {/* 9. FAQs support accordions */}
      <FAQSection />

      {/* 10. Maps location office contacts information */}
      <AboutContactMap />

      {/* 11. Sleek copyright branding footers */}
      <Footer />

      {/* ========================================================== */}
      {/* FLOATING EXTRA UTILITY COMPONENTS & DRAWERS */}
      {/* ========================================================== */}

      {/* A. PRODUCT POPUP VIEW DETAILED MODAL */}
      {selectedProduct && (
        <ProductPopup 
          product={selectedProduct}
          onClose={() => setSelectedProduct(null)}
          onAddToCart={handleAddToCart}
          onDirectCheckout={handleDirectCheckout}
        />
      )}

      {/* B. MERCHANT ADMIN/SELLER DASHBOARD CONTROL DRAWER */}
      <AdminPanel 
        isOpen={isAdminOpen}
        onClose={() => setIsAdminOpen(false)}
        orders={orders}
        sheetUrl={sheetUrl}
        onSaveSheetUrl={handleSaveSheetUrl}
        onClearOrders={handleClearOrders}
      />

      {/* C. SHOPPING CART SIDE DRAWER SIDE PANEL */}
      {isCartOpen && (
        <div className="fixed inset-0 z-50 overflow-hidden flex justify-end">
          <div onClick={() => setIsCartOpen(false)} className="fixed inset-0 bg-black/50 backdrop-blur-xs"></div>
          
          <div className="bg-[#FCFBF7] w-full max-w-md h-full relative z-10 flex flex-col justify-between shadow-2xl border-l border-gray-100 animate-slide-in p-6 select-none text-left">
            
            {/* Header */}
            <div>
              <div className="flex items-center justify-between pb-4 border-b border-gray-100">
                <h4 className="font-serif text-lg font-bold text-gray-900 flex items-center gap-2">
                  <span>🐝</span> শপিং কার্ট তালিকা
                </h4>
                <button 
                  onClick={() => setIsCartOpen(false)} 
                  className="p-1.5 rounded-xl bg-gray-100 text-gray-400 hover:text-gray-700 cursor-pointer"
                >
                  <X size={18} />
                </button>
              </div>

              {/* Items List */}
              {cartItems.length === 0 ? (
                <div className="py-24 text-center text-gray-400 flex flex-col items-center justify-center">
                  <ShoppingBag size={48} strokeWidth={1} className="text-gray-300" />
                  <p className="text-xs font-bold text-gray-500 mt-4 leading-normal">আপনার শপিং কার্ট খালি আছে।</p>
                  <p className="text-[10px] text-gray-400 mt-1">পছন্দের পণ্যটি সিলেক্ট করে কার্টে যোগ করুন।</p>
                  <button
                    onClick={() => {
                      setIsCartOpen(false);
                      handleScrollToDiv('#products');
                    }}
                    className="mt-6 py-2 px-4 bg-amber-500 text-white font-sans text-xs font-bold rounded-xl shadow-md cursor-pointer"
                  >
                    মধু সম্ভার দেখুন
                  </button>
                </div>
              ) : (
                <div className="mt-4 flex flex-col gap-4 overflow-y-auto max-h-[60vh] pr-1">
                  {cartItems.map((item, idx) => (
                    <div key={idx} className="flex gap-3 pb-3 border-b border-gray-50 items-center justify-between">
                      <img 
                        src={item.product.image} 
                        alt={item.product.name} 
                        className="w-14 h-14 object-cover rounded-xl border border-gray-100 shrink-0"
                      />
                      <div className="flex-1 min-w-0">
                        <h4 className="font-bold text-xs truncate text-[#111827]">{item.product.name}</h4>
                        <span className="text-[10px] text-gray-400 font-bold bg-neutral-100 px-1.5 py-0.5 rounded-md mt-1 inline-block">
                          ওজন: {item.selectedWeight}
                        </span>
                      </div>
                      <div className="text-right flex flex-col shrink-0">
                        <span className="font-bold text-xs text-gray-900 font-mono">৳{item.selectedPrice * item.quantity}</span>
                        <span className="text-[9px] text-gray-400 mt-1">({item.quantity} পিস)</span>
                        <button 
                          onClick={() => handleRemoveFromCart(idx)}
                          className="text-[10px] text-red-500 hover:underline mt-1 font-bold"
                        >
                          বাদ দিন
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Total checkout footer summary */}
            {cartItems.length > 0 && (
              <div className="border-t border-gray-100 pt-4 flex flex-col gap-4">
                <div className="flex justify-between items-baseline">
                  <span className="text-xs font-bold text-gray-500">কার্ট সাব-টোটাল বিল:</span>
                  <span className="font-bold font-sans text-gray-900 text-lg font-mono">
                    ৳{cartItems.reduce((acc, item) => acc + (item.selectedPrice * item.quantity), 0)}
                  </span>
                </div>
                
                <p className="text-[10px] text-emerald-600 font-bold bg-emerald-50 px-3 py-1.5 rounded-xl border border-emerald-100 text-left leading-normal">
                  🌱 অফার: ২ পিস বা তার বেশি অর্ডারে পুরো সারা বাংলাদেশে কুরিয়ার হোম ডেলিভারি ফি একদম ফ্রি!
                </p>

                <div className="grid grid-cols-2 gap-2">
                  <button
                    onClick={() => setIsCartOpen(false)}
                    className="py-3 bg-gray-100 hover:bg-gray-200 text-gray-700 font-bold text-2xs uppercase tracking-wider rounded-xl transition-all cursor-pointer text-center"
                  >
                    শপিং কন্টিনিউ
                  </button>
                  <button
                    onClick={() => {
                      setIsCartOpen(false);
                      handleScrollToDiv('#checkout-section');
                    }}
                    className="py-3 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-600 text-white font-bold text-2xs uppercase tracking-wider rounded-xl shadow-lg shadow-amber-500/10 cursor-pointer text-center"
                  >
                    অর্ডার ফর্ম পূরণ
                  </button>
                </div>
              </div>
            )}

          </div>
        </div>
      )}

      {/* D. FLOATING SOCIAL WHATSAPP CONTACT FLOATER BUTTON */}
      <div className="fixed bottom-6 right-6 z-30 flex flex-col gap-3.5 select-none">
        
        {/* Back to Top button */}
        {showScrollTop && (
          <button
            onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
            className="p-3 bg-white hover:bg-neutral-50 text-gray-600 hover:text-amber-500 rounded-full shadow-lg border border-gray-100 transition-all hover:-translate-y-1 active:scale-90 cursor-pointer flex items-center justify-center shrink-0 h-10 w-10 md:h-12 md:w-12"
            title="Scroll to Top"
          >
            <ArrowUp size={20} />
          </button>
        )}

        {/* WhatsApp Call support CTA */}
        <a
          href="https://wa.me/8801700000000?text=আসসালামু%20আলাইকুম।%20আমি%20Pure%20Honey%20BD%20থেকে%20মধু%20অর্ডার%20করতে%20চাই।"
          target="_blank"
          rel="noreferrer"
          className="p-3 bg-[#25D366] hover:bg-[#20ba5a] text-white rounded-full shadow-xl shadow-emerald-600/25 cursor-pointer block text-center transform transition-all hover:scale-110 active:scale-95 shrink-0 flex items-center justify-center h-10 w-10 md:h-12 md:w-12 animate-bounce"
          title="WhatsApp Quick Order Consultation"
        >
          <MessageSquare size={22} fill="currentColor" className="stroke-none text-white font-bold" />
        </a>
      </div>

      {/* E. STICKY MOBILE BOTTOM QUICK ORDER ACCENT BAR */}
      <div className="fixed bottom-0 left-0 w-full bg-white/95 backdrop-blur-md border-t border-gray-200/50 p-3 flex sm:hidden items-center justify-between z-30 shadow-2xl">
        <div className="text-left flex flex-col">
          <span className="text-[10px] text-gray-400 font-bold uppercase leading-none">কার্ট বিল:</span>
          <span className="font-bold text-[#111827] text-sm font-mono mt-1">
            ৳{cartItems.reduce((acc, item) => acc + (item.selectedPrice * item.quantity), 0)} ({cartItems.reduce((acc, item) => acc + item.quantity, 0)} আইটেম)
          </span>
        </div>

        <button
          onClick={() => handleScrollToDiv('#checkout-section')}
          className="bg-amber-500 hover:bg-amber-600 active:scale-95 text-white font-bold text-xs p-2.5 px-5 rounded-lg shadow-md leading-none flex items-center gap-1 cursor-pointer font-sans"
        >
          <ShoppingCart size={13} />
          <span>অর্ডার ফর্ম ফর্ম</span>
        </button>
      </div>

      {/* F. FAKE PURCHASE REAL-TIME ALERTS POPUP NOTIFIER */}
      {fakeNotification && (
        <div className="fixed bottom-6 left-6 z-40 bg-white rounded-3xl p-4 shadow-2xl border border-amber-500/10 max-w-[280px] animate-slide-in font-sans text-xs hidden sm:flex items-center gap-3 text-left">
          <div className="h-10 w-10 bg-[#FAF1DF] text-amber-950 rounded-xl flex items-center justify-center shrink-0 font-serif text-lg">
            🐝
          </div>
          <div className="flex flex-col min-w-0">
            <h5 className="font-serif font-black text-[#111827] truncate leading-none">
              {fakeNotification.buyer}
            </h5>
            <span className="text-[10px] text-[#059669] font-bold leading-normal mt-1 block">
              📍 {fakeNotification.location}
            </span>
            <p className="text-[10px] text-gray-500 mt-1 truncate leading-relaxed">
              অর্ডার করেছেন {fakeNotification.qty} {fakeNotification.product}
            </p>
            <span className="text-[9px] text-gray-400 mt-0.5 font-semibold font-mono">{fakeNotification.ago}</span>
          </div>
        </div>
      )}

    </div>
  );
}
