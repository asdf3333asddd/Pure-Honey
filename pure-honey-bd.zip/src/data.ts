import { Product, Testimonial, FAQItem } from './types';

// Let's import generated image paths
export const PREMIUM_HONEY_JAR_IMG = "/src/assets/images/premium_honey_jar_1780026203554.png";
export const HARVEST_PROCESS_IMG = "/src/assets/images/honey_collection_process_1780026233876.png";

export const PRODUCTS: Product[] = [
  {
    id: "sundarban-honey",
    name: "সুন্দরবন প্রাকৃতিক মধু",
    englishName: "Sundarban Mangrove Honey",
    shortDescription: "সুন্দরবনের খলিশা ও গড়ান ফুলের খাঁটি প্রাকৃতিক চাক কাটা মধু।",
    longDescription: "সুন্দরবনের গহীন অরণ্য থেকে মৌয়ালদের দ্বারা সংগ্রহ করা সম্পূর্ণ প্রাকৃতিক ও খাঁটি মধু। এই মধুর বিশেষত্ব হলো এর হালকা টক-মিষ্টি স্বাদ এবং পাতলা ঘনত্বের চমৎকার ফ্লেভার। এটি প্রাকৃতির অন্যতম সেরা অ্যান্টিঅক্সিডেন্ট এবং রোগ প্রতিরোধ ক্ষমতা বৃদ্ধিতে অত্যন্ত কার্যকর।",
    scientificName: "Apis dorsata / Mangrove Nectar",
    harvestArea: "Sundarbans Mangrove Forest, Bangladesh",
    tasteProfile: "Fruity sweet with mild woody & tangy undertones",
    color: "Light Amber/Golden with bright clarity",
    stockStatus: "In Stock",
    bestFor: "Curing cold & cough, strengthening absolute immunity",
    rating: 4.9,
    reviewCount: 148,
    image: "https://images.unsplash.com/photo-1587132137056-bfbf0166836e?auto=format&fit=crop&q=80&w=800",
    benefits: [
      "রোগ প্রতিরোধ ক্ষমতা বহুগুণ বাড়িয়ে তোলে।",
      "শরীরের ক্লান্তি ও অবসাদ দূর করে মেটাবলিজম বাড়ায়।",
      "কাশি, গলাব্যথা ও ফুসফুসের সমস্যায় চমৎকার কাজ করে।",
      "এটি হজম শক্তি বৃদ্ধি করতে সরাসরি সাহায্য করে।"
    ],
    defaultPrice: 950,
    originalPrice: 1200,
    weightOptions: [
      { weight: "250g", price: 300, discountPrice: 260 },
      { weight: "500g", price: 550, discountPrice: 480 },
      { weight: "1kg", price: 1000, discountPrice: 920 }
    ]
  },
  {
    id: "kalojira-honey",
    name: "কালোজিরা ফুলের মধু",
    englishName: "Kalojira Flower Honey",
    shortDescription: "কালোজিরা ফুলের মহৌষধি গুণসম্পন্ন অত্যন্ত প্রিমিয়াম গ্রেডের মধু।",
    longDescription: "কালোজিরা চাষের ক্ষেত থেকে মৌমাছির সাহায্যে সংগৃহীত অত্যন্ত ঔষধি ও প্রিমিয়াম গুণের মধু। মহান আল্লাহ কালোজিরাকে সর্বরোগের মহৌষধ বানিয়েছেন, আর এর ফুলের মধু মানেই দ্বিগুণ উপকারিতা। এর স্বাদ চমৎকার মিষ্টি এবং ঘ্রাণে কালোজিরার আলতো ছোঁয়া রয়েছে।",
    scientificName: "Nigella sativa Nectar",
    harvestArea: "Gopalganj & Shariatpur Blackseed Gardens",
    tasteProfile: "Highly sweet, rich, with herbal black seed aroma",
    color: "Deep Blackish Dark Amber with high viscosity",
    stockStatus: "Limited Stock",
    bestFor: "Natural body heating, chronic weakness, asthma relief",
    rating: 4.9,
    reviewCount: 232,
    image: "https://images.unsplash.com/photo-1471193945509-9ad0617afabf?auto=format&fit=crop&q=80&w=800",
    benefits: [
      "হাঁপানি বা অ্যাজমা রোগীদের জন্য অত্যন্ত উপকারী শ্বাসতন্ত্র রক্ষাকারী।",
      "স্মৃতিশক্তি ও ব্রেইনের কার্যক্ষমতা দ্বিগুণ করতে সহায়তা করে।",
      "রক্তচাপ নিয়ন্ত্রণে রাখতে সাহায্য করে এবং হৃদপিন্ড ভালো রাখে।",
      "যৌন স্বাস্থ্য ও স্নায়ুর শক্তি বৃদ্ধিতে এটি মহৌষধ হিসেবে কাজ করে।"
    ],
    defaultPrice: 1100,
    originalPrice: 1400,
    weightOptions: [
      { weight: "250g", price: 350, discountPrice: 320 },
      { weight: "500g", price: 650, discountPrice: 580 },
      { weight: "1kg", price: 1250, discountPrice: 1080 }
    ]
  },
  {
    id: "pahari-honey",
    name: "পার্বত্য বুনো মধু",
    englishName: "Pahari Wild Honey",
    shortDescription: "বান্দরবান ও খাগড়াছড়ির পাহাড়ের গহীন বনের প্রাকৃতিকভাবে চাক কাটা মধু।",
    longDescription: "পাহাড়ের দুর্গম এলাকায় বড় বড় গাছের চূড়ায় এবং পাথরের খাঁজে থাকা পাহাড়ি বুনো মৌমাছির বড় ডাব বা চাক থেকে কেটে আনা পাহাড়ি বুনো মধু। এটি শতভাগ প্রাকৃতিকভাবে সংগৃহীত এবং তীব্র সুগন্ধযুক্ত। এটিতে বিভিন্ন দুর্লভ বুনো ওষধি উদ্ভিদের নির্যাস বিদ্যমান থাকে।",
    scientificName: "Wild Mountain Forest Nectar",
    harvestArea: "Bandarban & Khagrachari Hills",
    tasteProfile: "Intense deep sweetness with herbal and earthy complexity",
    color: "Reddish Dark Gold",
    stockStatus: "In Stock",
    bestFor: "Direct nutrient supply, natural stamina, cell recovery",
    rating: 4.8,
    reviewCount: 95,
    image: "https://images.unsplash.com/photo-1558642452-9d2a7deb7f62?auto=format&fit=crop&q=80&w=800",
    benefits: [
      "শতভাগ প্রাকৃতিকভাবে তৈরি বিধায় বুনো ঔষধি গুণসম্পন্ন।",
      "রক্তস্বল্পতা বা এনিমিয়া প্রতিরোধে দ্রুত রক্তকণিকা বাড়ায়।",
      "শরীর গঠনে মাংসপেশি সুদৃঢ় করে ও অতিরিক্ত ক্যালোরি বার্ন করে।",
      "ত্বক উজ্জ্বল ও মসৃণ রাখতে বাহ্যিক রূপচর্চাতেও ব্যবহৃত হয়।"
    ],
    defaultPrice: 1000,
    originalPrice: 1300,
    weightOptions: [
      { weight: "250g", price: 350, discountPrice: 300 },
      { weight: "500g", price: 600, discountPrice: 550 },
      { weight: "1kg", price: 1100, discountPrice: 980 }
    ]
  },
  {
    id: "sorisha-honey",
    name: "সরিষা ফুলের খাঁটি মধু",
    englishName: "Sorisha Flower Honey",
    shortDescription: "সরিষা ফুলের সুমিষ্ট ও ক্রিমি টেক্সচারের অত্যন্ত চমৎকার মধু।",
    longDescription: "শীতকালে সরিষা ক্ষেতের সুঘ্রাণময় হলুদ ফুলের ওপর চাষ করা বাক্সের মৌমাছি দিয়ে বিশেষ উপায়ে সংগৃহীত মধু। সরিষা ফুলের মধুর অন্যতম প্রাকৃতিক বৈশিষ্ট্য হলো এটি শীতকালে অথবা ঠান্ডা আবহাওয়ায় স্বাভাবিকভাবেই জমে সাদা ক্রিমের মতো হয়ে যায়, যা শতভাগ আসল মধুর প্রমাণ।",
    scientificName: "Brassica napus Nectar",
    harvestArea: "Tangail & Manikganj Mustard Fields",
    tasteProfile: "Sweet, buttery, with a pleasant mustard flower aftertaste",
    color: "Pale Creamy Yellow (turns solidwhite naturally)",
    stockStatus: "In Stock",
    bestFor: "Bone health, instant energy before workout, natural sugar substitute",
    rating: 4.7,
    reviewCount: 164,
    image: "https://images.unsplash.com/photo-1563245372-f21724e3856d?auto=format&fit=crop&q=80&w=800",
    benefits: [
      "উচ্চ ক্যালসিয়াম সমৃদ্ধ যা হাড় ও দাঁত মজবুত করতে সাহায্য করে।",
      "শরীরে দ্রুত তাপ সঞ্চার করে এবং ঠান্ডা ও শীতকালীন বাতের ব্যথা কমায়।",
      "খারাপ কোলেস্টেরল কমিয়ে রক্তের প্রবাহ স্বাভাবিক রাখে।",
      "চা বা কফিতে প্রাকৃতিক মিষ্টতা যোগ করার জন্য এটি আদর্শ।"
    ],
    defaultPrice: 650,
    originalPrice: 800,
    weightOptions: [
      { weight: "250g", price: 220, discountPrice: 180 },
      { weight: "500g", price: 400, discountPrice: 340 },
      { weight: "1kg", price: 750, discountPrice: 620 }
    ]
  },
  {
    id: "litchu-honey",
    name: "লিচু ফুলের খাঁটি মধু",
    englishName: "Litchi Flower Honey",
    shortDescription: "লিচুর বাগানে মৌমাছি দ্বারা সংগৃহীত হালকা ও অত্যন্ত লোভনীয় স্বাদের মধু।",
    longDescription: "দিনাজপুর ও রাজশাহীর বিশাল লিচু বাগানগুলোতে ফুল ফোটার মৌসুমে বিশেষ বাক্সের মৌমাছি দিয়ে সংগৃহীত মধু। এই মধুটির প্রধান ও শ্রেষ্ঠ আকর্ষণ হলো এর চমৎকার সুগন্ধ এবং পানির মতো স্বচ্ছ ও হালকা টেক্সচার। এটি ছোট বাচ্চারাসহ সবাই অত্যন্ত পছন্দ করে।",
    scientificName: "Litchi chinensis Nectar",
    harvestArea: "Dinajpur & Rajshahi Litchi Orchards",
    tasteProfile: "Light, delightfully sweet, with a clear fruity litchi scent",
    color: "Amber Transparent with light gold hue",
    stockStatus: "In Stock",
    bestFor: "Children health, refreshing morning drinks, glowing skin",
    rating: 4.8,
    reviewCount: 110,
    image: "https://images.unsplash.com/photo-1608797178974-15b35a61d121?auto=format&fit=crop&q=80&w=800",
    benefits: [
      "বাচ্চাদের ক্ষুধা বাড়াতে এবং হজম প্রক্রিয়া সুস্থ রাখতে ব্যাপক সাহায্য করে।",
      "শরীরে ইনস্ট্যান্ট এনার্জি যোগায় যা দীর্ঘ সময়ের কাজের ক্লান্তি নিরাময় করে।",
      "ত্বকের উজ্জ্বলতা দীর্ঘস্থায়ী করে ও ফুসকুড়ি আমাশয় কমায়।",
      "হালকা টেক্সচার হওয়ায় সহজে পানির সাথে মিশে ডিটক্স ওয়াটার বানাতে সাহায্য করে।"
    ],
    defaultPrice: 700,
    originalPrice: 900,
    weightOptions: [
      { weight: "250g", price: 230, discountPrice: 200 },
      { weight: "500g", price: 430, discountPrice: 380 },
      { weight: "1kg", price: 800, discountPrice: 680 }
    ]
  },
  {
    id: "mixed-honey",
    name: "মিশ্র ফুলের বহুমুখী মধু",
    englishName: "Mixed Flower Honey",
    shortDescription: "গ্রামীণ বিভিন্ন ফুলের সুবাস ও প্রাকৃতিক নির্যাস সমৃদ্ধ খাঁটি মধু।",
    longDescription: "পল্লী অঞ্চলের বিভিন্ন দেশীয় ফুল ও বুনো গাছপালা থেকে সংগৃহীত আমাদের নিয়মিত কোয়ালিটির মাল্টিফ্লাওয়ার মধু। একাধিক ফুলের প্রাকৃতিক নির্যাস থাকায় এর ওষধিগুণ অত্যন্ত বহুমুখী এবং স্বাদেও একটি সমৃদ্ধ প্রথাগত মধুর অনুভূতি উপহার দেয়। দৈনিক ব্যবহারের জন্য একদম আদর্শ।",
    scientificName: "Polyfloral Honey Nectar",
    harvestArea: "Rural regions of Jessore & Kushtia",
    tasteProfile: "Standard classic honey sweetness, balanced and rich",
    color: "Rich Golden Brown",
    stockStatus: "In Stock",
    bestFor: "Daily family consumption, breakfast pancakes, general fitness",
    rating: 4.7,
    reviewCount: 121,
    image: "https://images.unsplash.com/photo-1615485290382-441e4d049cb5?auto=format&fit=crop&q=80&w=800",
    benefits: [
      "রোজ সকালে কুসুম গরম পানিতে মিশিয়ে খেলে ওজন ও চর্বি নিয়ন্ত্রণ করে।",
      "সারাদিনের শারীরিক পুষ্টির অভাব পূরণে অন্যতম প্রাকৃতিক উৎস।",
      "কোষ্ঠকাঠিন্য ও গ্যাস্ট্রিকের সমস্যায় অত্যন্ত ফলপ্রসূ উপকার দান করে।",
      "শিশুদের ঠান্ডাজনিত শ্বাসনালীর ইনফেকশনে সুরক্ষাবলয় তৈরি করে।"
    ],
    defaultPrice: 650,
    originalPrice: 850,
    weightOptions: [
      { weight: "250g", price: 200, discountPrice: 170 },
      { weight: "500g", price: 380, discountPrice: 320 },
      { weight: "1kg", price: 700, discountPrice: 590 }
    ]
  }
];

export const TESTIMONIALS: Testimonial[] = [
  {
    id: "t1",
    name: "আরিফ রহমান",
    location: "উত্তরা, ঢাকা",
    rating: 5,
    comment: "সুন্দরবনের মধুটা সত্যিই অসাধারণ! খুবই চমৎকার আর খাঁটি গন্ধ। অন্য জায়গায় কিনে অনেকবার প্রতারিত হয়েছি, কিন্তু Pure Honey BD এর মধু নিয়ে একদম নিশ্চিন্ত হওয়া গেল। ডেলিভারি মাত্র ২৪ ঘণ্টায় পেয়েছি।",
    avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=150",
    verified: true,
    date: "মে ১৫, ২০২৬",
    productBought: "Sundarban Mangrove Honey"
  },
  {
    id: "t2",
    name: "ফাতেমা তুজ জোহরা",
    location: "খুলনা সদর",
    rating: 5,
    comment: "বাচ্চাদের প্রতিদিন সকালে কালোজিরা মধু খাইয়ে থাকি। কালোজিরা মধুর টেক্সচার আর সুঘ্রাণটাই আলাদা। আর Pure Honey BD আমাদের খুলনার হয়েও নিখুঁত ডেলিভারি আর কোয়ালিটি রক্ষা করেছে। ধন্যবাদ আপনাদের!",
    avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&q=80&w=155",
    verified: true,
    date: "মে ২৩, ২০২৬",
    productBought: "Kalojira Flower Honey"
  },
  {
    id: "t3",
    name: "মেহেদী হাসান সোহাগ",
    location: "নাসিরাবাদ, চট্টগ্রাম",
    rating: 4,
    comment: "সরিষা ফুলের মধু নিয়েছিলাম। ঠাণ্ডা আসার সাথে সাথেই এটা জমে সাদা ক্রিমের মতো হয়ে গেছে। প্রথমে ভয় পেয়েছিলাম চিনি কি না, পরে টেস্ট করে বুঝলাম এটাই আসল সরিষার দানাদার মধুর আসল রূপ। হাড়ের ব্যথায় বেশ উপকার পাচ্ছি।",
    avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&q=80&w=150",
    verified: true,
    date: "মে ২৫, ২০২৬",
    productBought: "Sorisha Flower Honey"
  },
  {
    id: "t4",
    name: "নুসরাত পারভীন",
    location: "সিলেট শাহজালাল উপশহর",
    rating: 5,
    comment: "পার্বত্য পাহাড়ের বুনো মধুটা অনেক ঘন আর তীব্র মিষ্টি ও ঔষধি ফ্লেভারযুক্ত। ল্যাব টেস্ট ল্যাবে না পাঠিয়েও গুণাগুণ বোঝা যায়। আমার কায়িক ও মানসিক দূরভীষণ চমৎকার কমেছে। প্যাকিং খুবই প্রিমিয়াম ছিল। কুরিয়ারও এক দিনে এসেছে।",
    avatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=150",
    verified: true,
    date: "মে ২৮, ২০২৬",
    productBought: "Pahari Wild Honey"
  }
];

export const FAQS: FAQItem[] = [
  {
    id: "faq1",
    category: "purity",
    question: "আপনাদের মধু খাঁটি হওয়ার নিশ্চয়তা বা গ্যারান্টি কী?",
    answer: "আমরা সরাসরি সুন্দরবনের মৌয়ালদের সাথে ও বিশ্বস্ত মৌ-চাষিদের সাথে যুক্ত থেকে মধু সংগ্রহ করি। কোনো প্রকার রাসায়নিক বা বাড়তি সুগার সিরাপ মেশানো হয় না। আমরা যেকোনো সময় এই মধু ল্যাব টেস্ট করানোর জন্য উন্মুক্ত রাখি। যদি আপনি কোনো খাঁটি প্রমাণের বিপরীতে ত্রুটি খুঁজে পান, তবে ১০০% ক্যাশব্যাক দেওয়া হবে।"
  },
  {
    id: "faq2",
    category: "crystallization",
    question: "চিংড়ি বা সরিষার মধু কি জমে যায়? সেটি কি ভেজাল?",
    answer: "একদম না। কিছু নির্দিষ্ট ফুলের মধু (বিশেষ করে সরিষা ফুল এবং লিচু ফুল) গ্লুকোজের প্রাকৃতিক পরিমাণের জন্য শীতকালে জমে সাদা ক্রিমের মতো হয়ে যায়। একে ক্রিস্টালাইজেশন বলা হয় যা আসল বা খাঁটি মধুর একটি অন্যতম বৈজ্ঞানিক বৈশিষ্ট্য। এটি ভেজালের লক্ষণ নয় বরঞ্চ এটি মধু খাঁটি হওয়ারই বড় প্রমাণ।"
  },
  {
    id: "faq3",
    category: "delivery",
    question: "ডেলিভারি চার্জ কত এবং কত দিনের মধ্যে পাওয়া যাবে?",
    answer: "সারা বাংলাদেশে ঢাকা সিটির ভেতরে ক্যাশ অন ডেলিভারিতে চার্জ মাত্র ৬০ টাকা এবং ঢাকার বাইরে ১৩০ টাকা। তবে আমাদের বিশেষ অফারে ২ কেজি বা তার বেশি মধু অর্ডার করলে একদম ফ্রি ক্যাশ অন ডেলিভারি কুরিয়ার করা হয়! সাধারণত অর্ডার কনফার্মের ২৪ থেকে ৪৮ ঘণ্টার মধ্যে আপনি হাতে পাবেন।"
  },
  {
    id: "faq4",
    category: "payment",
    question: "আমি কি পণ্য হাতে পেয়ে দেখে টাকা পরিশোধ করতে পারবো?",
    answer: "হ্যাঁ, অবশ্যই! আমরা সারা বাংলাদেশে হোম ডেলিভারিতে 'ক্যাশ অন ডেলিভারি' (COD) সুবিধা দিচ্ছি। কুরিয়ার বয় পণ্য নিয়ে যাওয়ার পর আপনি প্যাকেট চেক করে ও দেখে কুরিয়ারের কাছে টাকা পরিশোধ করতে পারবেন।"
  },
  {
    id: "faq5",
    category: "weight",
    question: "আপনাদের মধুর ছোট সাইজের বা ট্রায়াল প্যাক আছে কি?",
    answer: "জি, প্রতিটি মধুরই ট্রায়াল প্যাকার সুবিধার্থে ২৫০ গ্রাম সাইজের সুন্দর কন্টেইনার রয়েছে। এর পাশাপাশি নিয়মিত ব্যবহারের জন্য ৫০০ গ্রাম ও ফ্যামিলি ব্যবহারের জন্য ১ কেজি সাইজ সাজানো হয়েছে। অর্ডার ফর্মেই আপনি পছন্দসই সাইজ ও ওজন সিলেক্ট করতে পারবেন।"
  }
];

export const BENEFITS_ITEMS = [
  {
    title: "১০০% খাঁটি ও প্রাকৃতিক",
    desc: "প্রকৃতির বুক থেকে সরাসরি সংগৃহিত। ফুড গ্রেড জার এবং নো-কেমিক্যাল ফিল্টারিং।",
    icon: "ShieldCheck",
    color: "from-amber-400 to-amber-600"
  },
  {
    title: "সংরক্ষণে ক্ষতিকর চিনি মুক্ত",
    desc: "কোনো প্রকার প্রিজারভেটিভস, সুগার সিরাপ বা কৃত্রিম ফ্লেভার নেই। সম্পূর্ণ র' হানি।",
    icon: "Ban",
    color: "from-yellow-400 to-amber-500"
  },
  {
    title: "সরাসরি খামারিদের থেকে",
    desc: "কোনো মধ্যস্বত্বভোগী ছাড়া সৎ মৌপালক ও মৌয়ালদের ন্যায্য পারিশ্রমিকে অংশীদারিত্ব।",
    icon: "Users",
    color: "from-emerald-400 to-emerald-600"
  },
  {
    title: "রোগ প্রতিরোধ ক্ষমতা বর্ধক",
    desc: "শরীরের অ্যান্টিবডি বৃদ্ধি করে সাধারণ সর্দি, কাশি এবং হৃদরোগ প্রতিরোধে কার্যকর সাহায্যকারী।",
    icon: "Heart",
    color: "from-red-400 to-pink-500"
  },
  {
    title: "ইনস্ট্যান্ট প্রাকৃতিক শক্তি",
    desc: "রক্তে দ্রুত মিশে ক্লান্তি দূর করে শরীরের পেশি ও মেদ কমিয়ে কর্মচঞ্চলতা ফিরিয়ে আনে।",
    icon: "Zap",
    color: "from-amber-500 to-orange-600"
  },
  {
    title: "গ্যারান্টিড ক্যাশব্যাক অফার",
    desc: "মধু খাঁটি প্রমাণ না লাগলে বা মান পছন্দ না হলে বিনাপ্রশ্নে ৭ দিনের মধ্যে টাকা ফেরত।",
    icon: "RotateCcw",
    color: "from-blue-400 to-indigo-500"
  }
];

export const STORIES_STEPS = [
  {
    step: "০১",
    title: "প্রাকৃতিক উৎস নির্বাচন",
    desc: "সুন্দরবনের গহীন ম্যানগ্রোভ অঞ্চল অথবা উত্তরবঙ্গের বিস্তৃত খাঁটি ফুলের খেত সুনির্দিষ্ট করে সংগ্রহ টিম প্রেরণ করা হয়।"
  },
  {
    step: "০২",
    title: "পদ্ধতিগত প্রাকৃতিক সংগ্রহ",
    desc: "মৌমাছির ক্ষতি না করে সম্পূর্ণ সনাতন ও পরিচ্ছন্ন হাইজেনিক ফিল্টার পদ্ধতিতে চাক থেকে সরাসরি মধু নিষ্কাশন করা হয়।"
  },
  {
    step: "০৩",
    title: "ল্যাব ও মান নিয়ন্ত্রণ",
    desc: "শতভাগ আর্দ্রতা পরীক্ষা করে ও ডাস্ট ফিল্টারিং করে কাঁচের জারে সুরক্ষিত করা হয় যেন দীর্ঘ বছর স্বাদের অবক্ষয় না ঘটে।"
  },
  {
    step: "০৪",
    title: "নিরাপদ প্যাকেজিং ও ডেলিভারি",
    desc: "কাঠের বক্স বা ডাবল-বাবল র্যাপ দিয়ে নিখুঁত প্যাকিং-এ গ্রাহকের হাতে ক্যাশ অন ডেলিভারিতে দ্রুত পৌঁছে যায়।"
  }
];
