import { useState, useEffect } from 'react';
import { ArrowRight, Star, Heart, Award, ArrowUpRight, TrendingUp } from 'lucide-react';
import { PREMIUM_HONEY_JAR_IMG } from '../data';

interface HeroSectionProps {
  onOrderNow: () => void;
  onViewProducts: () => void;
}

export default function HeroSection({ onOrderNow, onViewProducts }: HeroSectionProps) {
  // Simple state for parallax effect
  const [offsetY, setOffsetY] = useState(0);

  useEffect(() => {
    const handleScroll = () => {
      setOffsetY(window.scrollY);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <section id="home" className="relative pt-12 pb-16 md:py-24 bg-gradient-to-br from-[#FDFCF8] to-[#F5F1E6] overflow-hidden">
      
      {/* Decorative Floating Background Elements (Bumblebees, Leaves, Drops) */}
      <div 
        className="absolute top-24 left-[8%] text-3xl opacity-20 hover:opacity-80 transition-opacity animate-float cursor-default"
        style={{ transform: `translateY(${offsetY * 0.15}px)` }}
      >
        🐝
      </div>
      <div 
        className="absolute bottom-32 left-[12%] text-4xl opacity-15 hover:opacity-80 transition-opacity animate-float-slow cursor-default"
        style={{ transform: `translateY(${offsetY * -0.07}px)` }}
      >
        🍃
      </div>
      <div 
        className="absolute top-36 right-[15%] text-2xl opacity-20 hover:opacity-80 transition-opacity animate-float-reverse cursor-default"
        style={{ transform: `translateY(${offsetY * 0.09}px)` }}
      >
        🌻
      </div>
      <div 
        className="absolute bottom-16 right-[10%] text-4xl opacity-20 hover:opacity-80 transition-opacity animate-float cursor-default"
        style={{ transform: `translateY(${offsetY * -0.12}px)` }}
      >
        🐝
      </div>

      {/* Background Soft Yellow Radial Lights */}
      <div className="absolute top-[20%] left-1/2 -translate-x-1/2 w-[70vw] h-[70vw] max-w-4xl max-h-4xl bg-gradient-to-tr from-[#D4AF37]/5 via-amber-200/5 to-transparent rounded-full blur-3xl -z-10 animate-beam"></div>

      <div className="max-w-7xl mx-auto px-4 md:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-8 items-center">
          
          {/* Left Text Content Area */}
          <div className="lg:col-span-7 flex flex-col items-start text-left z-10">
            
            {/* Top organic claim pill badge */}
            <div className="inline-flex items-center gap-1.5 bg-[#1B3022]/5 border border-[#1B3022]/10 px-4 py-1.5 rounded-full text-[#1B3022] text-[10px] font-bold uppercase tracking-[0.2em] mb-6 select-none">
              <span className="flex h-1.5 w-1.5 rounded-full bg-[#D4AF37]"></span>
              <span>১০% খাঁটি ও প্রাকৃতিক মধুর সমাহার</span>
            </div>

            {/* Main Editorial Headline */}
            <h1 id="hero-title" className="font-serif text-4xl sm:text-5xl md:text-6xl text-[#111111] leading-[1.05] font-semibold tracking-tighter">
              প্রকৃতির সুধা, <span className="italic font-light text-[#D4AF37]">সুস্থতার</span> সমাধান <br />
              <span className="text-[#1B3022] font-bold block mt-3">
                শতভাগ খাঁটি কাঁচা মধু সরাসরি খামার থেকে!
              </span>
            </h1>

            {/* English Subheadline */}
            <p className="font-sans text-[11px] font-bold uppercase tracking-[0.25em] text-[#D4AF37] mt-5 leading-normal">
              Raw, Organic, Unfiltered Honey Essence
            </p>

            {/* Description Paragraph */}
            <p id="hero-desc" className="font-sans text-sm md:text-base text-gray-600 mt-4 leading-relaxed max-w-lg font-light">
              আমরা কোনো কৃত্রিম হিটিং, চিনি বা ক্ষতিকর রাসায়নিক ফিল্টারিং ছাড়াই সুন্দরবন, পার্বত্য অঞ্চল এবং বুনো মৌয়ালদের খাঁটি চাক কাটা মধু সংগ্রহ করে প্রিমিয়াম কাঁচের জারে গ্রাহকের ঠিকানায় নিরাপদে পৌঁছে দেই।
            </p>

            {/* Highlights bullet features block */}
            <div className="grid grid-cols-2 md:grid-cols-3 gap-3 w-full mt-8 max-w-lg">
              <div className="flex items-center gap-2 bg-[#FDFCF8]/80 backdrop-blur-sm p-3 rounded-lg border border-black/5 shadow-sm">
                <div className="h-7 w-7 bg-[#1B3022]/5 text-[#1B3022] rounded flex items-center justify-center font-bold text-xs select-none">✓</div>
                <div className="flex flex-col select-none">
                  <span className="font-bold text-[11px] text-[#111111] uppercase tracking-wide">১০০% অর্গানিক</span>
                  <span className="text-[9px] text-gray-400">সম্পূর্ণ প্রাকৃতিক</span>
                </div>
              </div>
              <div className="flex items-center gap-2 bg-[#FDFCF8]/80 backdrop-blur-sm p-3 rounded-lg border border-black/5 shadow-sm">
                <div className="h-7 w-7 bg-[#1B3022]/5 text-[#1B3022] rounded flex items-center justify-center font-bold text-xs select-none">✓</div>
                <div className="flex flex-col select-none">
                  <span className="font-bold text-[11px] text-[#111111] uppercase tracking-wide">হাতে পেয়ে পরীক্ষা</span>
                  <span className="text-[9px] text-gray-400">দেখে নেওয়ার সুযোগ</span>
                </div>
              </div>
              <div className="col-span-2 md:col-span-1 flex items-center gap-2 bg-[#FDFCF8]/80 backdrop-blur-sm p-3 rounded-lg border border-black/5 shadow-sm">
                <div className="h-7 w-7 bg-[#1B3022]/5 text-[#1B3022] rounded flex items-center justify-center font-bold text-xs select-none">✓</div>
                <div className="flex flex-col select-none">
                  <span className="font-bold text-[11px] text-[#111111] uppercase tracking-wide">ক্যাশব্যাক অফার</span>
                  <span className="text-[9px] text-gray-400">২ গুন্ ক্ষতিপূরণ ফেরত</span>
                </div>
              </div>
            </div>

            {/* Marketing Buttons Group */}
            <div className="flex flex-wrap items-center gap-4 mt-8 w-full">
              <button
                id="hero-order-btn"
                onClick={onOrderNow}
                className="bg-[#111111] hover:bg-neutral-800 text-white font-sans font-bold text-xs uppercase tracking-widest px-8 py-4 shadow-md transition-all active:scale-95 cursor-pointer flex items-center gap-2 leading-none"
              >
                <span>সরাসরি অর্ডার করুন</span>
                <ArrowRight size={14} />
              </button>
              
              <button
                id="hero-view-products-btn"
                onClick={onViewProducts}
                className="bg-transparent hover:bg-black/5 text-[#111111] font-sans font-bold text-xs uppercase tracking-widest px-6 py-4 border border-black/10 shadow-none transition-all active:scale-95 cursor-pointer flex items-center gap-1.5"
              >
                <span>মধু সম্ভার দেখুন</span>
                <ArrowUpRight size={14} className="text-[#D4AF37]" />
              </button>
            </div>

            {/* Social Trust Banner */}
            <div className="flex items-center gap-4 mt-8 flex-wrap pt-4 border-t border-black/5 w-full">
              <div className="flex -space-x-2">
                <img className="w-8 h-8 rounded-full border-2 border-[#FDFCF8] object-cover" src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=100" alt="Buyer" referrerPolicy="no-referrer" />
                <img className="w-8 h-8 rounded-full border-2 border-[#FDFCF8] object-cover" src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=100" alt="Buyer" referrerPolicy="no-referrer" />
                <img className="w-8 h-8 rounded-full border-2 border-[#FDFCF8] object-cover" src="https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&q=80&w=100" alt="Buyer" referrerPolicy="no-referrer" />
              </div>
              <div className="flex flex-col text-xs leading-tight">
                <div className="flex items-center gap-0.5 text-[#D4AF37]">
                  <Star size={11} fill="currentColor" />
                  <Star size={11} fill="currentColor" />
                  <Star size={11} fill="currentColor" />
                  <Star size={11} fill="currentColor" />
                  <Star size={11} fill="currentColor" />
                  <span className="text-gray-800 font-bold ml-1 text-2xs md:text-xs">4.9 / 5.0</span>
                </div>
                <span className="text-gray-400 font-bold uppercase tracking-wider text-[9px] mt-0.5">৫,০০০+ বিশ্বস্ত পরিবারের আস্থায় Pure Honey BD</span>
              </div>
            </div>

          </div>

          {/* Right Floating Product Graphic Area */}
          <div className="lg:col-span-5 flex justify-center items-center relative py-6">
            
            {/* Ambient Background Glow Backdrop */}
            <div className="absolute top-[20%] left-[20%] w-[80%] h-[80%] bg-[#D4AF37]/5 rounded-full blur-3xl animate-pulse"></div>

            {/* Honey Comb Shaped Decoration behind the Jar */}
            <div className="absolute -z-10 translate-y-4 translate-x-4 opacity-[0.02] pointer-events-none text-black">
              <svg width="280" height="280" viewBox="0 0 100 100" fill="currentColor">
                <path d="M 50,0 L 93.3,25 L 93.3,75 L 50,100 L 6.7,75 L 6.7,25 Z" />
              </svg>
            </div>

            {/* Main Premium Illustration Image Layout */}
            <div className="relative w-full max-w-[340px] md:max-w-[400px] aspect-square rounded-3xl overflow-visible group flex justify-center items-center">
              
              {/* Outer floating drop stickers */}
              <div className="absolute -top-4 -left-4 bg-[#FDFCF8] p-3 rounded-lg shadow-sm border border-black/5 flex items-center gap-2 z-20 animate-float-slow">
                <div className="h-6 w-6 bg-[#D4AF37]/10 text-[#D4AF37] rounded-full flex items-center justify-center text-xs select-none">🐝</div>
                <div className="flex flex-col text-left">
                  <span className="text-[8px] text-gray-400 font-bold uppercase tracking-widest leading-none">ORIGIN RANGE</span>
                  <span className="text-[10px] text-gray-800 font-bold leading-tight mt-0.5">শতভাগ প্রাকৃতিক সোর্সিং</span>
                </div>
              </div>

              <div className="absolute -bottom-2 -right-4 bg-[#FDFCF8] p-3 rounded-lg shadow-sm border border-black/5 flex items-center gap-3.5 z-20 animate-float">
                <div className="relative">
                  <div className="h-7 w-7 bg-[#1B3022]/10 text-[#1B3022] rounded flex items-center justify-center font-bold text-xs"><Award size={14} /></div>
                  <span className="absolute -top-1 -right-1 flex h-2 w-2">
                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-[#1B3022] opacity-75"></span>
                    <span className="relative inline-flex rounded-full h-2 w-2 bg-[#1B3022]"></span>
                  </span>
                </div>
                <div className="flex flex-col text-left">
                  <span className="text-[8px] text-gray-400 font-bold uppercase tracking-widest leading-none">PREMIUM LAB REPORT</span>
                  <span className="text-[10px] text-gray-800 font-bold leading-tight mt-0.5">ল্যাব টেস্ট সার্টিফাইড</span>
                </div>
              </div>

              {/* Main Rounded Jar Image with Golden Ambient Outline */}
              <div className="w-[85%] h-[85%] bg-[#F5F1E6] rounded-2xl shadow-xl relative overflow-hidden flex items-center justify-center border border-black/5 transform transition-transform duration-500 hover:scale-102 group">
                <img 
                  id="hero-main-image"
                  src={PREMIUM_HONEY_JAR_IMG} 
                  alt="Premium Organic Honey Jar from Pure Honey BD" 
                  className="w-full h-full object-cover rounded-2xl transform transition-transform duration-700 group-hover:scale-105"
                  referrerPolicy="no-referrer"
                />
                
                {/* Overlay gold honey color theme shade */}
                <div className="absolute inset-0 bg-gradient-to-t from-black/10 via-transparent to-transparent opacity-60"></div>
              </div>

              {/* Decorative Animated Honey dripping vector */}
              <div className="absolute top-[8%] right-[10%] w-14 opacity-25 hover:opacity-90 transition-opacity animate-drip">
                <svg viewBox="0 0 40 80" className="text-[#D4AF37] fill-current">
                  <path d="M20,0 C20,0 20,40 20,40 C20,40 38,45 38,58 C38,68 30,76 20,76 C10,76 2,68 2,58 C2,45 20,40 20,40 Z" />
                </svg>
              </div>

            </div>

          </div>

        </div>
      </div>
    </section>
  );
}
