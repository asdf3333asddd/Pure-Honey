import { useState, useEffect } from 'react';
import { Menu, X, ShoppingBag, ArrowRight } from 'lucide-react';
import { CartItem } from '../types';

interface NavbarProps {
  onOpenCart: () => void;
  cartItems: CartItem[];
  cartCount: number;
}

export default function Navbar({ onOpenCart, cartItems, cartCount }: NavbarProps) {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 40) {
        setIsScrolled(true);
      } else {
        setIsScrolled(false);
      }
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { label: "হোম", href: "#home" },
    { label: "মধু সম্ভার", href: "#products" },
    { label: "বিশেষত্ব", href: "#benefits" },
    { label: "আমাদের গল্প", href: "#story" },
    { label: "রিভিউ", href: "#reviews" },
    { label: "এফএকিউ", href: "#faq" },
    { label: "যোগাযোগ", href: "#contact" }
  ];

  const handleLinkClick = (href: string) => {
    setIsMobileMenuOpen(false);
    const targetElement = document.querySelector(href);
    if (targetElement) {
      targetElement.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handleOrderNow = () => {
    const target = document.querySelector("#checkout-section");
    if (target) {
      target.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <>
      <header
        id="premium-navbar"
        className={`sticky top-0 z-40 transition-all duration-300 w-full ${
          isScrolled
            ? 'bg-[#FDFCF8]/95 backdrop-blur-md shadow-sm border-b border-black/5 py-3.5'
            : 'bg-[#FDFCF8]/50 py-5'
        }`}
      >
        <span className="hidden">Pure Honey BD Navbar</span>
        <div className="max-w-7xl mx-auto px-4 md:px-6 lg:px-8 flex items-center justify-between">
          
          {/* Logo Brand Name */}
          <a
            id="navbar-logo"
            href="#home"
            onClick={(e) => {
              e.preventDefault();
              handleLinkClick("#home");
            }}
            className="flex items-center gap-3 group cursor-pointer"
          >
            {/* Elegant Honey Pot Representation with Lucide Icons */}
            <div className="relative h-9 w-9 bg-[#D4AF37] rounded-lg flex items-center justify-center text-white shadow-sm group-hover:scale-105 transition-transform">
              <span className="text-lg font-bold">🐝</span>
            </div>
            <div className="flex flex-col">
              <span className="font-serif italic font-bold text-[18px] md:text-[22px] tracking-tight text-[#111111] flex items-center gap-0.5 leading-none">
                Pure Honey <span className="text-[#D4AF37] font-semibold">BD</span>
              </span>
              <span className="text-[9px] font-sans font-bold tracking-widest text-emerald-800 uppercase mt-0.5 leading-none">
                100% Organic Raw
              </span>
            </div>
          </a>

          {/* Desktop Navigation Link Menu */}
          <nav htmlFor="menu-checkbox" className="hidden lg:flex items-center gap-8 text-[11px] uppercase font-bold tracking-widest">
            {navLinks.map((link) => (
              <a
                id={`navbar-link-${link.href.slice(1)}`}
                key={link.href}
                href={link.href}
                onClick={(e) => {
                  e.preventDefault();
                  handleLinkClick(link.href);
                }}
                className="text-gray-600 hover:text-[#111111] transition-colors duration-200 relative group py-2"
              >
                {link.label}
                <span className="absolute bottom-0 left-0 w-0 h-[1.5px] bg-[#D4AF37] transition-all duration-300 group-hover:w-full"></span>
              </a>
            ))}
          </nav>

          {/* Action Blocks: Shopping Cart & Order Now button */}
          <div className="flex items-center gap-3 md:gap-4">
            
            {/* Shopping Cart button with Dynamic animation/badge */}
            <button
              id="navbar-cart-btn"
              onClick={onOpenCart}
              className="relative p-2.5 rounded-lg bg-transparent hover:bg-black/5 transition-all text-[#111111] border border-black/10 flex items-center justify-center group"
              title="View Cart & Order"
            >
              <ShoppingBag size={18} className="group-hover:scale-105 transition-transform" />
              {cartCount > 0 && (
                <span className="absolute -top-1.5 -right-1.5 min-w-[18px] h-4.5 bg-[#D4AF37] text-white font-bold text-[10px] rounded-full flex items-center justify-center px-1 shadow-sm border border-white animate-pulse">
                  {cartCount}
                </span>
              )}
            </button>

            {/* Quick Order Now button with Arrow effect */}
            <button
              id="navbar-order-btn"
              onClick={handleOrderNow}
              className="hidden sm:flex items-center gap-2 bg-[#111111] hover:bg-neutral-800 text-white font-sans font-bold text-[11px] uppercase tracking-widest px-6 py-3 shadow-md hover:shadow-lg transition-all active:scale-95 cursor-pointer leading-none"
            >
              <span>অর্ডার করুন</span>
              <ArrowRight size={12} />
            </button>

            {/* Mobile hamburger toggle element */}
            <button
              id="navbar-mobile-menu-toggle"
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className="lg:hidden p-2 text-gray-800 hover:bg-[#F3F4F6] rounded-xl transition-all"
            >
              {isMobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
        </div>
      </header>

      {/* Mobile Drawer Navigation Menu */}
      <div
        id="navbar-mobile-drawer"
        className={`fixed inset-0 z-35 transform ${
          isMobileMenuOpen ? 'translate-x-0' : '-translate-x-full'
        } transition-transform duration-300 lg:hidden bg-[#FDFCF8] flex flex-col justify-start pt-24 px-6 gap-6`}
      >
        <div className="absolute top-6 left-6 text-xl font-bold flex items-center gap-2">
          <span className="text-[#D4AF37]">🐝</span>
          <span className="font-serif italic font-bold text-lg text-gray-900">Pure Honey BD</span>
        </div>

        <button
          onClick={() => setIsMobileMenuOpen(false)}
          className="absolute top-6 right-6 p-2 rounded-lg bg-black/5 text-gray-700 hover:bg-black/10"
        >
          <X size={20} />
        </button>

        <nav className="flex flex-col gap-4 text-base font-bold text-gray-800 tracking-wider">
          {navLinks.map((link) => (
            <a
              id={`mobile-navbar-link-${link.href.slice(1)}`}
              key={link.href}
              href={link.href}
              onClick={(e) => {
                e.preventDefault();
                handleLinkClick(link.href);
              }}
              className="py-2.5 border-b border-black/5 hover:text-[#D4AF37] flex items-center justify-between transition-colors"
            >
              <span>{link.label}</span>
              <span className="text-[#D4AF37] font-sans">➔</span>
            </a>
          ))}
        </nav>

        <div className="mt-8 flex flex-col gap-4">
          <button
            id="mobile-navbar-order-now-btn"
            onClick={() => {
              setIsMobileMenuOpen(false);
              handleOrderNow();
            }}
            className="w-full text-center bg-[#111111] hover:bg-neutral-800 text-white font-bold py-3.5 px-4 tracking-widest uppercase text-xs"
          >
            সরাসরি অর্ডার করুন
          </button>
          <p className="text-center text-[10px] text-gray-400 font-sans tracking-wide">
            📞 হটলাইন: +8801700-000000 (সকাল ৯টা - রাত ১০টা)
          </p>
        </div>
      </div>
    </>
  );
}
