import { useState, FormEvent } from 'react';
import { Phone, Mail, MapPin, Send, Facebook, MessageSquare, Clock } from 'lucide-react';

export default function AboutContactMap() {
  const [contactName, setContactName] = useState('');
  const [contactEmail, setContactEmail] = useState('');
  const [contactMessage, setContactMessage] = useState('');
  const [isSending, setIsSending] = useState(false);
  const [feedback, setFeedback] = useState('');

  const handleSendMessage = (e: FormEvent) => {
    e.preventDefault();
    if (!contactName.trim() || !contactMessage.trim()) {
      setFeedback("দয়া করে নাম ও বার্তার ঘরটি পূরণ করুন।");
      return;
    }
    setIsSending(true);
    setFeedback('');

    setTimeout(() => {
      setIsSending(false);
      setFeedback("ধন্যবাদ! আপনার বার্তাটি সফলভাবে প্রেরণ করা হয়েছে। আমরা দ্রুত মোবাইল বা ইমেইলে যোগাযোগ করবো।");
      setContactName('');
      setContactEmail('');
      setContactMessage('');
    }, 1500);
  };

  return (
    <>
      {/* 1. ABOUT US SECTION */}
      <section id="about" className="py-20 bg-[#F5F1E6] relative overflow-hidden font-sans">
        <span className="hidden">Pure Honey BD Brand Story Sourcing Sincerity</span>
        <div className="max-w-7xl mx-auto px-4 md:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
            
            {/* Left side Image (5 cols) */}
            <div className="lg:col-span-5 relative">
              <div className="absolute top-[10%] left-[10%] w-[80%] h-[80%] bg-[#D4AF37]/5 rounded-full blur-3xl -z-10 animate-pulse"></div>
              
              <div className="relative aspect-square w-full rounded-lg overflow-hidden border border-black/5 shadow-md group">
                <img 
                  src="https://images.unsplash.com/photo-1473081556163-2a17de81fc97?auto=format&fit=crop&q=80&w=800" 
                  alt="Pure organic bee farming honey comb flowers" 
                  className="w-full h-full object-cover transform duration-500 group-hover:scale-102"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent"></div>
                <div className="absolute bottom-6 left-6 text-left select-none">
                  <span className="bg-[#D4AF37] text-white font-serif text-[10px] font-bold uppercase tracking-widest px-3 py-1.5 rounded-sm shadow-xs">
                    NATURAL & HONEST
                  </span>
                  <h4 className="font-serif text-white font-bold text-base mt-2 shadow-xs leading-tight">বিশ্বস্ত খামারি পার্টনারশিপ</h4>
                </div>
              </div>
            </div>

            {/* Right side Text Content (7 cols) */}
            <div className="lg:col-span-7 text-left">
              <div className="inline-flex items-center gap-1.5 bg-[#1B3022]/10 text-[#1B3022] px-4 py-1.5 rounded-full text-[10px] font-bold uppercase tracking-[0.2em] mb-3 select-none">
                <span>🌱</span> আমাদের পরিচিতি ও সততা
              </div>
              
              <h2 className="font-serif text-3xl md:text-4xl lg:text-5xl text-[#111111] font-semibold tracking-tight">
                শতভাগ অর্গানিক মধুর বিশ্বস্ত ব্র্যান্ড <br />
                <span className="text-[#1B3022] font-semibold">“Pure Honey BD”</span>
              </h2>

              <p className="font-sans text-sm text-gray-500 mt-5 leading-relaxed font-light">
                বাংলাদেশ একটি agri-কমিউনিটি প্রধান বা কৃষিপ্রধান দেশ যেখানে প্রতি বছর বহু বৈচিত্র্যময় ফুলের বীজ বপন করা হয়। এই ফুলের উপর ভরসা রেখেই মৌ মৌ চাষীরা খাঁটি প্রাকৃতিক মধু সংগ্রহ করে থাকেন। আমরা কোনো মধ্যস্বত্বভোগী ছাড়া সরাসরি সুদূর সুন্দরবন এবং সারা দেশের বিশ্বস্ত খামারিদের ডেক্স থেকে সরাসরি র’ বা কাঁচা মধু সংগ্রহ করে থাকি।
              </p>
              
              <p className="font-sans text-xs md:text-sm text-gray-400 mt-4 leading-relaxed font-light">
                আমাদের উদ্দেশ্য হলো বাণিজ্যিকভাবে কেবল লাভবান হওয়া নয়, বরং দেশের প্রতিটি নাগরিকের কাছে সুস্বাদু ও ভেজালহীন মধু পৌঁছে দেয়া যা পরম রোগ প্রতিষেধক হিসেবে তাদের আয়ু ও সুস্বাস্থ্য বাড়াবে। প্যাক করার ক্ষেত্রে আমরা কঠোর হাইজেনিক নিয়মকানুন বজায় রাখি যেন কাচের প্রতিটি জারে মধুর সুবাস ঠিক সমান সুবর্ণ থাকে।
              </p>

              {/* USP List */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-8 font-sans">
                <div className="flex items-start gap-2">
                  <span className="text-[#D4AF37] font-bold select-none text-base">🍯</span>
                  <div className="flex flex-col">
                    <span className="font-semibold text-xs text-gray-900">গ্যারান্টিযুক্ত সর্বোচ্চ আর্দ্রতা নিয়ন্ত্রণ</span>
                    <span className="text-[10px] text-gray-400 font-light">ফিল্টারিং জারে মধুর স্থায়ী স্থায়িত্ব বজায় রাখতে</span>
                  </div>
                </div>
                <div className="flex items-start gap-2">
                  <span className="text-[#1B3022] font-bold select-none text-base">🌱</span>
                  <div className="flex flex-col">
                    <span className="font-semibold text-xs text-gray-950">শুধুমাত্র কাচের প্রিমিয়াম জারে বোতলজাত</span>
                    <span className="text-[10px] text-gray-400 font-light">প্লাস্টিকের ক্ষতিকর রাসায়নিক উপাদান মুক্ত</span>
                  </div>
                </div>
              </div>

            </div>

          </div>
        </div>
      </section>

      {/* 2. CONTACT US & LOCATION SECTION */}
      <section id="contact" className="py-20 bg-[#FDFCF8] relative font-sans">
        <span className="hidden">Pure Honey BD Physical Sourcing Location Cover</span>
        <div className="max-w-7xl mx-auto px-4 md:px-6 lg:px-8">
          
          {/* Section title */}
          <div className="text-center max-w-3xl mx-auto mb-16">
            <div className="inline-flex items-center gap-1.5 bg-[#1B3022]/10 text-[#1B3022] px-4 py-1.5 rounded-full text-[10px] font-bold uppercase tracking-[0.2em] mb-3 select-none">
              <span>✍</span> সংযোগের মেলবন্ধন
            </div>
            <h2 className="font-serif text-3xl md:text-4xl lg:text-5xl text-[#111111] font-semibold tracking-tight">
              আমাদের ঠিকানা ও কাস্টমার সার্ভিস
            </h2>
            <div className="h-[1.5px] w-24 bg-[#D4AF37] mx-auto mt-4"></div>
            <p className="font-sans text-sm text-gray-500 mt-5 leading-relaxed font-light">
              যেকোনো পাইকারি সরবরাহ, বিশেষ কুপন ডিল, বা সন্দেহ দূরীকরণে আমাদের হটলাইন বা কাস্টমার কেয়ারে সশরীরে যোগাযোগ করুন।
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-stretch max-w-6xl mx-auto">
            
            {/* Left Box: Sourcing Contacts details (4 cols) */}
            <div className="lg:col-span-4 bg-[#F5F1E6] p-6 md:p-8 rounded-lg border border-black/5 flex flex-col justify-between text-left h-full shadow-xs">
              <div>
                <h3 className="font-serif text-lg md:text-xl font-bold text-[#111111] mb-6">জরুরি যোগাযোগ কার্ড</h3>
                
                <div className="flex flex-col gap-6 font-sans">
                  <div className="flex items-start gap-3.5">
                    <div className="h-9 w-9 bg-[#FDFCF8] border border-black/5 text-[#D4AF37] rounded flex items-center justify-center shadow-xs shrink-0">
                      <Phone size={16} />
                    </div>
                    <div className="flex flex-col text-left">
                      <span className="text-[10px] text-gray-400 font-bold uppercase tracking-wider">মোবাইল হটলাইন:</span>
                      <a href="tel:+8801700000000" className="text-sm font-extrabold text-[#111111] font-mono italic hover:underline mt-0.5">+৮৮০ ১৭০০-০০০০০০</a>
                    </div>
                  </div>

                  <div className="flex items-start gap-3.5">
                    <div className="h-9 w-9 bg-[#FDFCF8] border border-black/5 text-emerald-700 rounded flex items-center justify-center shadow-xs shrink-0">
                      <MessageSquare size={16} />
                    </div>
                    <div className="flex flex-col text-left">
                      <span className="text-[10px] text-gray-400 font-bold uppercase tracking-wider">হোয়াটসঅ্যাপ চ্যাট:</span>
                      <a href="https://wa.me/8801700000000" target="_blank" rel="noreferrer" className="text-sm font-extrabold text-emerald-700 font-mono hover:underline mt-0.5">+৮৮০ ১৭০০-০০০০০০</a>
                    </div>
                  </div>

                  <div className="flex items-start gap-3.5">
                    <div className="h-9 w-9 bg-[#FDFCF8] border border-black/5 text-[#1B3022] rounded flex items-center justify-center shadow-xs shrink-0">
                      <Facebook size={16} />
                    </div>
                    <div className="flex flex-col text-left">
                      <span className="text-[10px] text-gray-400 font-bold uppercase tracking-wider">ফেসবুক পেজ লিংক:</span>
                      <a href="https://facebook.com/purehoneybd" target="_blank" rel="noreferrer" className="text-sm font-semibold text-gray-800 hover:underline mt-0.5">fb.com/purehoneybd_official</a>
                    </div>
                  </div>

                  <div className="flex items-start gap-3.5">
                    <div className="h-9 w-9 bg-[#FDFCF8] border border-black/5 text-rose-700 rounded flex items-center justify-center shadow-xs shrink-0">
                      <Mail size={16} />
                    </div>
                    <div className="flex flex-col text-left">
                      <span className="text-[10px] text-gray-400 font-bold uppercase tracking-wider">ইমেইল ঠিকানা:</span>
                      <a href="mailto:asarfina05@gmail.com" className="text-sm font-semibold text-gray-800 font-mono hover:underline mt-0.5">info@purehoneybd.com</a>
                    </div>
                  </div>

                  <div className="flex items-start gap-3.5">
                    <div className="h-9 w-9 bg-[#FDFCF8] border border-black/5 text-gray-700 rounded flex items-center justify-center shadow-xs shrink-0">
                      <MapPin size={16} />
                    </div>
                    <div className="flex flex-col text-left">
                      <span className="text-[10px] text-gray-400 font-bold uppercase tracking-wider">অফিস ও আউটলেট:</span>
                      <span className="text-xs text-gray-600 font-light leading-relaxed mt-0.5">১ম তলা, হোল্ডিং নং-৪৫, রোড নং-১০, সেক্টর-৩, উত্তরা মডেল টাউন, ঢাকা-১২৩০</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Operational timings */}
              <div className="pt-6 border-t border-black/5 mt-6 flex items-center gap-2.5 text-xs text-gray-400 font-sans">
                <Clock size={14} className="text-[#D4AF37]" />
                <span className="font-light">অফিস সময়: প্রতিদিন সকাল ৯:০০ টা - রাত ৮:০০ টা</span>
              </div>
            </div>

            {/* Middle Box: Google Maps container (4 cols) */}
            <div className="lg:col-span-4 rounded-lg overflow-hidden border border-black/5 shadow-sm relative h-[320px] lg:h-auto min-h-[300px]">
              {/* Responsive Google Maps embed with Dhaka City focus */}
              <iframe 
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m12!1m3!1d14594.131102910793!2d90.38896175000001!3d23.86277645!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3755c422c06913e1%3A0xa12ca26e838e12ec!2sSector%203%2C%20Uttara%2C%20Dhaka%201230!5e0!3m2!1sen!2sbd!4v1716942123512!5m2!1sen!2sbd" 
                className="w-full h-full border-none absolute inset-0"
                allowFullScreen={false} 
                loading="lazy" 
                referrerPolicy="no-referrer-when-downgrade"
              ></iframe>
              <div className="absolute bottom-4 left-4 bg-[#FDFCF8]/95 backdrop-blur-sm p-3.5 rounded border border-black/5 text-left pointer-events-none shadow-sm max-w-[200px]">
                <span className="text-[10px] text-emerald-700 font-bold block leading-none">✓ COVERAGE REGION</span>
                <span className="text-[11px] font-serif font-bold text-[#111111] mt-1.5 block">সারা দেশে কুরিয়ার হোম ডেলিভারি!</span>
              </div>
            </div>

            {/* Right Box: Quick Messaging Form (4 cols) */}
            <div className="lg:col-span-4 bg-[#FDFCF8] p-6 md:p-8 rounded-lg border border-black/5 shadow-xs text-left h-full">
              <h3 className="font-serif text-lg md:text-xl font-bold text-[#111111] pb-3 border-b border-black/5 flex items-center gap-1.5">
                <span>✉</span> ইমেইল বার্তা কুইক বক্স:
              </h3>

              {feedback && (
                <div className={`mt-4 p-3.5 rounded text-xs font-semibold border ${
                  feedback.includes("ত্রুটি") || feedback.includes("পূরণ")
                    ? 'bg-red-50 text-red-700 border-red-100'
                    : 'bg-emerald-50 text-emerald-700 border-emerald-100'
                }`}>
                  {feedback}
                </div>
              )}

              <form onSubmit={handleSendMessage} className="mt-5 flex flex-col gap-3 font-sans">
                <div className="flex flex-col">
                  <span className="text-[10px] text-gray-400 font-bold uppercase tracking-wider mb-1">আপনার নাম:</span>
                  <input 
                    type="text"
                    required
                    placeholder="যেমন: সাকিব হাসান"
                    value={contactName}
                    onChange={(e) => setContactName(e.target.value)}
                    className="border border-black/10 rounded-lg bg-black/[0.01] p-2 text-xs focus:outline-none focus:ring-1 focus:ring-[#D4AF37] focus:border-[#D4AF37] focus:bg-white transition-all h-9 font-light"
                    disabled={isSending}
                  />
                </div>

                <div className="flex flex-col">
                  <span className="text-[10px] text-gray-400 font-bold uppercase tracking-wider mb-1">মোবাইল বা ইমেইল:</span>
                  <input 
                    type="text"
                    required
                    placeholder="যেমন: user@gmail.com বা 017XX"
                    value={contactEmail}
                    onChange={(e) => setContactEmail(e.target.value)}
                    className="border border-black/10 rounded-lg bg-black/[0.01] p-2 text-xs focus:outline-none focus:ring-1 focus:ring-[#D4AF37] focus:border-[#D4AF37] focus:bg-white transition-all h-9 font-light"
                    disabled={isSending}
                  />
                </div>

                <div className="flex flex-col">
                  <span className="text-[10px] text-gray-400 font-bold uppercase tracking-wider mb-1">আপনার জিজ্ঞাসা বা বার্তা:</span>
                  <textarea 
                    required
                    placeholder="মধু সম্পর্কে কী জানতে চান লিখুন..."
                    value={contactMessage}
                    onChange={(e) => setContactMessage(e.target.value)}
                    className="border border-black/10 rounded-lg bg-black/[0.01] p-3 text-xs focus:outline-none focus:ring-1 focus:ring-[#D4AF37] focus:border-[#D4AF37] focus:bg-white transition-all min-h-[90px] text-left font-light"
                    disabled={isSending}
                  />
                </div>

                <button
                  type="submit"
                  className="w-full bg-[#111111] hover:bg-[#222222] text-[#FDFCF8] font-bold text-[10px] uppercase tracking-widest py-3 rounded-lg shadow-sm cursor-pointer flex items-center justify-center gap-1.5 transition-all active:scale-95 mt-2 h-10 leading-none"
                  disabled={isSending}
                >
                  {isSending ? (
                    <span>সেন্ড হচ্ছে...</span>
                  ) : (
                    <>
                      <Send size={12} className="text-white" />
                      <span>জিজ্ঞাসা পেশ করুন</span>
                    </>
                  )}
                </button>
              </form>
            </div>

          </div>

        </div>
      </section>
    </>
  );
}
