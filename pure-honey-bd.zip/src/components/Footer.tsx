import { Facebook, MessageSquare, Phone, Mail, Award, Shield } from 'lucide-react';

export default function Footer() {
  
  const handleScroll = (href: string) => {
    const target = document.querySelector(href);
    if (target) {
      target.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <footer className="bg-[#1B3022] text-[#F5F1E6]/70 font-sans text-xs md:text-sm pt-16 pb-8 border-t border-black/5 relative overflow-hidden text-left sm:text-center lg:text-left">
      <span className="hidden">Pure Honey BD Brand footer links</span>
      
      {/* Golden top beam line */}
      <div className="absolute top-0 left-0 w-full h-[1.5px] bg-[#D4AF37]"></div>

      <div className="max-w-7xl mx-auto px-4 md:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-10 pb-12 border-b border-white/10">
          
          {/* Logo & Bio Column (5 Columns) */}
          <div className="lg:col-span-5 flex flex-col items-start text-left">
            <div className="flex items-center gap-2.5 mb-4 group select-none">
              <div className="h-9 w-9 bg-[#D4AF37] rounded flex items-center justify-center text-white font-bold shadow-xs">
                🐝
              </div>
              <span className="font-serif font-extrabold text-[#FDFCF8] text-lg tracking-tight">
                Pure Honey <span className="text-[#D4AF37]">BD</span>
              </span>
            </div>

            <p className="text-xs text-gray-300 leading-relaxed max-w-sm font-light">
              &quot;Pure Honey BD&quot; বাংলাদেশের খাঁটি সংগৃহীত প্রাকৃতিক মধু সরবরাহকারী প্রতিষ্ঠান। মৌয়ালদের সরাসরি তত্ত্বাবধানে ও পরিচ্ছন্ন ফিল্টারিং ডেক্স-এ বোতলজাত করে আমরা গুণগত মানের সর্বোচ্চ নিশ্চিয়তা দিয়ে থাকি।
            </p>

            {/* Certifications badges visual icons */}
            <div className="flex gap-4 mt-6 select-none flex-wrap">
              <div className="flex items-center gap-1.5 bg-white/5 rounded px-2.5 py-1.5 border border-white/10 text-[10px] font-bold uppercase tracking-wider text-[#D4AF37]">
                <Award size={12} />
                <span>BSTI মানসম্পন্ন</span>
              </div>
              <div className="flex items-center gap-1.5 bg-white/5 rounded px-2.5 py-1.5 border border-white/10 text-[10px] font-bold uppercase tracking-wider text-emerald-300">
                <Shield size={12} />
                <span>১০০% হালাল ফুড</span>
              </div>
            </div>
          </div>

          {/* Quick Links Column (3 Columns) */}
          <div className="lg:col-span-3 text-left">
            <h4 className="font-serif font-bold text-xs uppercase tracking-widest text-[#D4AF37] mb-4">মৌলিক সাইট ম্যাপ</h4>
            <ul className="flex flex-col gap-2 font-light">
              {[
                { label: 'হোম ডেক্স', href: '#home' },
                { label: 'মধু সম্ভার কালেকশন', href: '#products' },
                { label: 'উপকারিতা ও বিশেষত্ব', href: '#benefits' },
                { label: 'আমাদের গল্প ও সংগ্রাহক', href: '#story' },
                { label: 'গ্রাহকদের মতামত (রিভিউ)', href: '#reviews' },
                { label: 'জিজ্ঞাসিত প্রশ্নাবলী (FAQ)', href: '#faq' }
              ].map((link) => (
                <li key={link.href}>
                  <a
                    href={link.href}
                    onClick={(e) => {
                      e.preventDefault();
                      handleScroll(link.href);
                    }}
                    className="hover:text-[#D4AF37] transition-colors flex items-center gap-1 group text-xs text-gray-300"
                  >
                    <span className="opacity-0 group-hover:opacity-100 transition-opacity text-[#D4AF37]">➔</span>
                    <span>{link.label}</span>
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Sourcing Information Column (4 Columns) */}
          <div className="lg:col-span-4 text-left">
            <h4 className="font-serif font-bold text-xs uppercase tracking-widest text-[#D4AF37] mb-4">আমাদের হেডকোয়ার্টার্স</h4>
            <p className="text-xs text-gray-300 leading-relaxed max-w-xs font-light">
              ১ম তলা, হোল্ডিং নং-৪৫, রোড নং-১০, সেক্টর-৩, উত্তরা মডেল টাউন, ঢাকা-১২৩০। <br />
              📞 হটলাইন নাম্বার: <strong>+৮৮০ ১৭০০-০০০০০০</strong>
            </p>

            {/* Float Social Links */}
            <div className="flex items-center gap-3 mt-6">
              <a
                href="https://facebook.com/purehoneybd" 
                target="_blank" 
                rel="noreferrer"
                className="h-8 w-8 bg-white/5 hover:bg-white/10 hover:text-white rounded border border-white/10 flex items-center justify-center text-gray-300 transition-colors"
                title="Facebook Page"
              >
                <Facebook size={14} />
              </a>
              <a
                href="https://wa.me/8801700000000" 
                target="_blank" 
                rel="noreferrer"
                className="h-8 w-8 bg-white/5 hover:bg-white/10 hover:text-white rounded border border-white/10 flex items-center justify-center text-gray-300 transition-colors"
                title="WhatsApp Support"
              >
                <MessageSquare size={14} />
              </a>
              <a
                href="tel:+8801700000000"
                className="h-8 w-8 bg-white/5 hover:bg-white/10 hover:text-white rounded border border-white/10 flex items-center justify-center text-gray-300 transition-colors"
                title="Direct Phone Support"
              >
                <Phone size={14} />
              </a>
              <a
                href="mailto:asarfina05@gmail.com"
                className="h-8 w-8 bg-white/5 hover:bg-white/10 hover:text-white rounded border border-white/10 flex items-center justify-center text-gray-300 transition-colors"
                title="Contact Email"
              >
                <Mail size={14} />
              </a>
            </div>
          </div>

        </div>

        {/* Bottom copyright & disclosures details */}
        <div className="pt-8 flex flex-col sm:flex-row sm:items-center justify-between gap-4 text-left sm:text-center text-2xs md:text-xs font-light">
          <p className="text-gray-400 font-light">
            &copy; {new Date().getFullYear()} <strong>Pure Honey BD</strong> (উত্তরা, ঢাকা). সর্বস্বত্ব সংরক্ষিত।
          </p>

          <div className="flex gap-4 font-semibold text-gray-400">
            <a href="#about" onClick={(e) => { e.preventDefault(); handleScroll('#about'); }} className="hover:text-[#D4AF37] transition-colors">Privacy Policy</a>
            <span className="text-white/10 select-none">|</span>
            <a href="#about" onClick={(e) => { e.preventDefault(); handleScroll('#about'); }} className="hover:text-[#D4AF37] transition-colors">Terms of Services</a>
            <span className="text-white/10 select-none">|</span>
            <a href="#about" onClick={(e) => { e.preventDefault(); handleScroll('#about'); }} className="hover:text-[#D4AF37] transition-colors">BSTI License</a>
          </div>
        </div>

      </div>
    </footer>
  );
}
