import { useState } from 'react';
import { Product, CartItem } from '../types';
import { PRODUCTS } from '../data';
import { ShoppingCart, Heart, ZoomIn, Sparkles, Check, ChevronRight } from 'lucide-react';

interface ProductSectionProps {
  onAddToCart: (product: Product, weight: string, price: number, quantity: number) => void;
  onSelectProduct: (product: Product) => void;
  onDirectCheckout: (product: Product, weight: string, price: number, quantity: number) => void;
}

export default function ProductSection({ onAddToCart, onSelectProduct, onDirectCheckout }: ProductSectionProps) {
  const [filterCategory, setFilterCategory] = useState<'all' | 'premium' | 'herbal' | 'popular'>('all');

  // Filter criteria logic
  const getFilteredProducts = () => {
    switch (filterCategory) {
      case 'premium':
        return PRODUCTS.filter(p => p.id === 'kalojira-honey' || p.id === 'sundarban-honey' || p.id === 'pahari-honey');
      case 'herbal':
        return PRODUCTS.filter(p => p.id === 'kalojira-honey' || p.id === 'pahari-honey' || p.id === 'sorisha-honey');
      case 'popular':
        return PRODUCTS.filter(p => p.id === 'sundarban-honey' || p.id === 'litchu-honey' || p.id === 'mixed-honey');
      default:
        return PRODUCTS;
    }
  };

  return (
    <section id="products" className="py-20 bg-[#FDFCF8] relative">
      <span className="hidden">Pure Honey BD Product Showcase</span>
      
      {/* Decorative Top Dripping Shape spacer */}
      <div className="absolute top-0 left-0 w-full overflow-hidden leading-none z-10 -translate-y-[1px]">
        <svg viewBox="0 0 1200 120" preserveAspectRatio="none" className="relative block h-[30px] w-full fill-[#F5F1E6] text-[#D4AF37] opacity-15">
          <path d="M0,0 C150,90 350,110 500,45 C650,-20 850,70 1000,55 C1150,40 1200,0 1200,0 L1200,120 L0,120 Z" />
        </svg>
      </div>

      <div className="max-w-7xl mx-auto px-4 md:px-6 lg:px-8 relative z-20">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="inline-flex items-center gap-1.5 bg-[#1B3022]/5 text-[#1B3022] px-4 py-1.5 rounded-full text-[10px] font-bold uppercase tracking-[0.2em] mb-3 select-none">
            <Sparkles size={11} className="text-[#D4AF37]" />
            <span>প্রাকৃতিক বিশুদ্ধতার অনন্য ছয়টি কালেকশন</span>
          </div>
          <h2 className="font-serif text-3xl md:text-4xl lg:text-5xl text-[#111111] font-semibold tracking-tight">
            আমাদের সুস্বাদু খাঁটি অর্গানিক মধু
          </h2>
          <div className="h-[1.5px] w-24 bg-[#D4AF37] mx-auto mt-4"></div>
          <p className="font-sans text-sm text-gray-500 mt-5 leading-relaxed font-light">
            আমরা প্রতিটি মধুর স্বকীয়তা বজায় রাখতে এবং সর্বোচ্চ পুষ্টিগুণ অক্ষুণ্ণ রাখতে সরাসরি কোনো প্রসেসিং ছাড়াই গ্রাহকের হাতে কাচের বৈয়ামে পাঠিয়ে থাকি। নিজের পছন্দসই খাঁটি মধু সিলেক্ট করুন।
          </p>
        </div>

        {/* Filter Navigation Tabs */}
        <div className="flex justify-center flex-wrap gap-2.5 mb-12">
          {[
            { id: 'all', label: 'সব মধু সম্ভার' },
            { id: 'premium', label: 'প্রিমিয়াম কালেকশন' },
            { id: 'herbal', label: 'মহৌষধি গুণসম্পন্ন' },
            { id: 'popular', label: 'সবচেয়ে চাহিদাসম্পন্ন' }
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setFilterCategory(tab.id as any)}
              className={`px-5 py-2.5 text-xs font-bold uppercase tracking-widest transition-all duration-300 cursor-pointer border ${
                filterCategory === tab.id
                  ? 'bg-[#111111] text-white border-[#111111] shadow-none scale-102'
                  : 'bg-transparent text-gray-500 border-black/10 hover:border-black/30 hover:text-[#111111]'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {/* Grid Container for Product Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 md:gap-6 lg:gap-8">
          {getFilteredProducts().map((product) => (
            <ProductCard 
              key={product.id} 
              product={product} 
              onAddToCart={onAddToCart}
              onSelectProduct={onSelectProduct}
              onDirectCheckout={onDirectCheckout}
            />
          ))}
        </div>

        {/* Bottom promo highlight */}
        <div className="mt-16 bg-gradient-to-r from-amber-50 via-orange-50 to-amber-50 p-6 md:p-8 rounded-2xl border border-amber-500/15 flex flex-col md:flex-row items-center justify-between gap-6 max-w-4xl mx-auto shadow-md">
          <div className="flex items-center gap-4 text-left">
            <div className="h-12 w-12 bg-amber-500/10 text-amber-600 rounded-2xl flex items-center justify-center font-serif text-2xl font-bold select-none shadow-inner border border-amber-500/5">
              🍯
            </div>
            <div className="flex flex-col">
              <h4 className="font-serif font-bold text-base md:text-lg text-gray-900 leading-tight">কোন মধু আপনার স্বাস্থ্যের জন্য সবচেয়ে সেরা?</h4>
              <p className="text-xs text-gray-500 mt-1 leading-relaxed">বুঝতে সমস্যা হচ্ছে? কোনো চিন্তা নেই! আমাদের সাথে ফ্রি পরামর্শ করতে এবং অর্ডার করতে পারেন সরাসরি হোয়াটসঅ্যাপে।</p>
            </div>
          </div>
          <a
            href="https://wa.me/8801700000000?text=আসসালামু%20আলাইকুম।%20আপনাদের%20খাঁটি%20মধু%20সম্পর্কে%20কিছু%20জানতে%20চাই।"
            target="_blank"
            rel="noreferrer"
            className="whitespace-nowrap inline-flex items-center gap-2 bg-[#059669] hover:bg-[#047857] text-[#FCFBF7] font-sans font-bold text-sm px-6 py-3 rounded-xl shadow-lg shadow-emerald-600/10 transition-all hover:-translate-y-0.5"
          >
            <span>হোয়াটসঅ্যাপে পরামর্শ করুন</span>
            <ChevronRight size={16} />
          </a>
        </div>

      </div>
    </section>
  );
}

/* Individual Product Card Component for Local Scoped Integrity */
interface ProductCardProps {
  key?: any;
  product: Product;
  onAddToCart: (product: Product, weight: string, price: number, quantity: number) => void;
  onSelectProduct: (product: Product) => void;
  onDirectCheckout: (product: Product, weight: string, price: number, quantity: number) => void;
}

function ProductCard({ product, onAddToCart, onSelectProduct, onDirectCheckout }: ProductCardProps) {
  // Local state to control active weight selection pill index
  const [selectedWeightIdx, setSelectedWeightIdx] = useState(0);
  const [quantity, setQuantity] = useState(1);
  const [isAdded, setIsAdded] = useState(false);

  const activeOption = product.weightOptions[selectedWeightIdx];
  const activePrice = activeOption.discountPrice || activeOption.price;
  const originalPrice = activeOption.price;

  const handleWeightChange = (index: number) => {
    setSelectedWeightIdx(index);
  };

  const handleAdd = () => {
    onAddToCart(product, activeOption.weight, activePrice, quantity);
    setIsAdded(true);
    setTimeout(() => {
      setIsAdded(false);
    }, 2000);
  };

  const handleCheckoutNow = () => {
    onDirectCheckout(product, activeOption.weight, activePrice, quantity);
  };

  const incrementQty = () => setQuantity(prev => prev + 1);
  const decrementQty = () => setQuantity(prev => (prev > 1 ? prev - 1 : 1));

  return (
    <div className="group bg-[#FDFCF8] border border-black/5 hover:border-[#D4AF37] overflow-hidden flex flex-col justify-between transition-all duration-300 hover:shadow-lg relative h-full">
      
      {/* Dynamic stock label sticker */}
      <span className="absolute top-4 left-4 z-20 bg-[#FDFCF8] px-2.5 py-1 text-[#1B3022] text-[9px] font-bold uppercase tracking-wider border border-black/5 shadow-sm flex items-center gap-1">
        <span className="h-1 w-1 bg-[#D4AF37]"></span>
        <span>{product.stockStatus}</span>
      </span>

      {/* Love reaction icon decoration */}
      <button 
        onClick={() => onSelectProduct(product)}
        className="absolute top-4 right-4 z-20 p-2 rounded-lg bg-[#FDFCF8]/95 text-gray-400 hover:text-[#D4AF37] border border-black/5 shadow-sm transition-transform active:scale-90"
        title="View details popup"
      >
        <ZoomIn size={14} />
      </button>

      {/* Interactive Image Container */}
      <div 
        onClick={() => onSelectProduct(product)}
        className="w-full aspect-video bg-[#F5F1E6] relative overflow-hidden cursor-pointer"
      >
        <img 
          src={product.image} 
          alt={product.name} 
          className="w-full h-full object-cover transform duration-500 group-hover:scale-103"
          referrerPolicy="no-referrer"
        />
        {/* Soft yellow tint layering */}
        <div className="absolute inset-0 bg-[#D4AF37]/5 mix-blend-multiply transition-opacity duration-300 group-hover:opacity-0"></div>
        
        {/* Overlay hover dipper effect */}
        <div className="absolute inset-0 bg-black/5 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
          <span className="bg-white text-gray-800 text-[10px] font-bold uppercase tracking-widest px-3 py-1.5 shadow-sm flex items-center gap-1 border border-black/10">
            <span>বিস্তারিত দেখুন</span>
            <ChevronRight size={10} className="text-[#D4AF37]" />
          </span>
        </div>
      </div>

      {/* Content wrapper */}
      <div className="p-5 flex-1 flex flex-col justify-between">
        <div className="text-left">
          {/* Subtitle location origin */}
          <span className="text-[9px] font-bold text-[#D4AF37] uppercase tracking-[0.2em]">{product.harvestArea}</span>
          
          {/* Bengali Title heading */}
          <h3 
            onClick={() => onSelectProduct(product)}
            className="font-serif text-lg font-bold text-[#111111] mt-1 hover:text-[#D4AF37] transition-colors cursor-pointer leading-tight"
          >
            {product.name}
          </h3>

          {/* English Subtitle */}
          <p className="font-sans text-[10px] font-bold tracking-widest uppercase text-emerald-800 mt-0.5">{product.englishName}</p>
          
          {/* Short Description */}
          <p className="text-xs text-gray-500 mt-2.5 leading-relaxed line-clamp-2 font-light">{product.shortDescription}</p>

          {/* Active Star Rating */}
          <div className="flex items-center gap-1.5 mt-3 select-none">
            <div className="flex items-center text-[#D4AF37]">
              <span className="text-xs">★</span>
              <span className="text-xs font-bold ml-1 text-gray-800">{product.rating}</span>
            </div>
            <span className="text-gray-200 font-sans text-2xs">|</span>
            <span className="text-[10px] text-gray-400 font-medium">({product.reviewCount} জনের রিভিউ)</span>
          </div>

          <hr className="my-4 border-black/5" />

          {/* Weight select label and pills */}
          <div className="flex flex-col text-left">
            <span className="text-[9px] text-[#111111] font-bold uppercase tracking-widest">মৌলিক ওজন সিলেক্ট করুন:</span>
            <div className="flex gap-1.5 mt-2">
              {product.weightOptions.map((opt, i) => (
                <button
                  key={opt.weight}
                  onClick={() => handleWeightChange(i)}
                  className={`flex-1 py-2 px-2.5 rounded-lg text-xs font-semibold transition-all cursor-pointer border flex flex-col items-center justify-center leading-none ${
                    selectedWeightIdx === i
                      ? 'bg-[#F5F1E6] text-[#111111] border-[#D4AF37] font-bold'
                      : 'bg-[#FDFCF8] text-gray-500 border-black/15 hover:border-[#D4AF37]'
                  }`}
                >
                  <span className="text-2xs sm:text-[11px]">{opt.weight}</span>
                  <span className="font-bold text-2xs opacity-75 mt-1 font-mono">
                    ৳{opt.discountPrice || opt.price}
                  </span>
                </button>
              ))}
            </div>
          </div>

          {/* Combined Pricing Display & Qty */}
          <div className="flex items-center justify-between mt-5">
            <div className="flex flex-col text-left">
              <span className="text-[9px] text-gray-400 font-bold uppercase tracking-widest leading-none">নির্ধারিত স্পেশাল মূল্য:</span>
              <div className="flex items-baseline gap-1.5 mt-1">
                <span className="font-sans font-extrabold text-[#111111] text-xl font-mono leading-none">৳{activePrice}</span>
                {activeOption.discountPrice && (
                  <span className="text-xs text-gray-400 line-through font-mono">৳{originalPrice}</span>
                )}
              </div>
            </div>

            {/* Micro Quantity adjustment */}
            <div className="flex items-center border border-black/10 rounded-lg p-0.5 h-8.5 bg-white shadow-none">
              <button 
                onClick={decrementQty}
                className="w-7 h-7 text-gray-500 hover:bg-neutral-100 active:scale-90 font-bold text-center flex items-center justify-center rounded-md"
              >
                -
              </button>
              <span className="w-6 text-center text-xs font-bold text-gray-800 font-mono">{quantity}</span>
              <button 
                onClick={incrementQty}
                className="w-7 h-7 text-gray-500 hover:bg-neutral-100 active:scale-90 font-bold text-center flex items-center justify-center rounded-md"
              >
                +
              </button>
            </div>
          </div>
        </div>

        {/* Call to Actions */}
        <div className="grid grid-cols-2 gap-2 mt-5">
          <button
            onClick={handleAdd}
            className={`py-2.5 border font-sans font-bold text-[10px] tracking-widest uppercase transition-all flex items-center justify-center gap-1 active:scale-95 cursor-pointer h-10 ${
              isAdded
                ? 'bg-[#1B3022]/10 text-[#1B3022] border-[#1B3022]/20'
                : 'bg-transparent text-gray-700 border-black/20 hover:border-black/50 hover:bg-black/[0.02]'
            }`}
          >
            {isAdded ? (
              <>
                <Check size={12} className="text-[#1B3022]" />
                <span>যোগ হয়েছে!</span>
              </>
            ) : (
              <>
                <ShoppingCart size={12} className="text-[#D4AF37]" />
                <span>কার্টে রাখুন</span>
              </>
            )}
          </button>

          <button
            onClick={handleCheckoutNow}
            className="bg-[#111111] hover:bg-neutral-800 text-white font-sans font-bold text-[10px] tracking-widest uppercase py-2.5 shadow-none active:scale-95 cursor-pointer flex items-center justify-center gap-1 h-10"
          >
            <span>এখনই কিনুন</span>
            <ChevronRight size={12} />
          </button>
        </div>
      </div>
    </div>
  );
}
