import { useState } from 'react';
import { OrderRecord } from '../types';
import { X, Save, Database, Copy, Check, Download, Trash2 } from 'lucide-react';

interface AdminPanelProps {
  isOpen: boolean;
  onClose: () => void;
  orders: OrderRecord[];
  sheetUrl: string;
  onSaveSheetUrl: (url: string) => void;
  onClearOrders: () => void;
}

export default function AdminPanel({ isOpen, onClose, orders, sheetUrl, onSaveSheetUrl, onClearOrders }: AdminPanelProps) {
  if (!isOpen) return null;

  const [inputUrl, setInputUrl] = useState(sheetUrl);
  const [isSaved, setIsSaved] = useState(false);
  const [isCopied, setIsCopied] = useState(false);
  const [activeTab, setActiveTab] = useState<'orders' | 'config' | 'guide'>('orders');

  const handleSaveUrl = () => {
    onSaveSheetUrl(inputUrl);
    setIsSaved(true);
    setTimeout(() => setIsSaved(false), 2000);
  };

  // Google Apps Script source code snippet
  const gasCode = `/**
 * Pure Honey BD - Google Sheets Order Sync script
 * Instructions:
 * 1. Open your Google Sheet
 * 2. Click Extensions > Apps Script
 * 3. Delete any default code and paste this script
 * 4. Click Deploy > New Deployment
 * 5. Under "Select type" click Web App
 * 6. Set "Execute as" to "Me", and "Who has access" to "Anyone"
 * 7. Deploy and copy the Web App URL into the Seller Dashboard!
 */

function doPost(e) {
  var sheet = SpreadsheetApp.getActiveSpreadsheet().getActiveSheet();
  
  // Set headers if the sheet is completely empty
  if (sheet.getLastRow() === 0) {
    sheet.appendRow([
      "Order ID", 
      "Customer Name", 
      "Phone Number", 
      "Full Address", 
      "Product Details", 
      "Total Price", 
      "Payment Method", 
      "Payment Account Number",
      "Transaction ID",
      "Timestamp / Date"
    ]);
  }
  
  try {
    var rawData = e.postData.contents;
    var data = JSON.parse(rawData);
    
    sheet.appendRow([
      data.orderId || "N/A",
      data.customerName || "N/A",
      "'" + (data.phone || "N/A"), // prefix with single quote to prevent leading-zero removal
      data.address || "N/A",
      data.productName || "N/A",
      data.totalPrice || 0,
      data.paymentMethod || "N/A",
      "'" + (data.paymentNumber || "N/A"),
      data.transactionId || "N/A",
      new Date().toLocaleString("en-US", {timeZone: "Asia/Dhaka"})
    ]);
    
    return ContentService.createTextOutput(JSON.stringify({ 
      "status": "success", 
      "message": "Order appended successfully to Google sheet!" 
    })).setMimeType(ContentService.MimeType.JSON);
    
  } catch(error) {
    return ContentService.createTextOutput(JSON.stringify({ 
      "status": "error", 
      "message": error.toString() 
    })).setMimeType(ContentService.MimeType.JSON);
  }
}`;

  const handleCopyCode = () => {
    navigator.clipboard.writeText(gasCode);
    setIsCopied(true);
    setTimeout(() => setIsCopied(false), 2000);
  };

  // CSV Exporter Action helper
  const handleExportCSV = () => {
    if (orders.length === 0) return;
    const headers = ["Order ID", "Customer Name", "Phone", "Address", "Products", "Total Price", "Payment Method", "Date"];
    const rows = orders.map(o => [
      o.id,
      o.customerName,
      o.phone,
      o.address.replace(/,/g, ' '),
      o.productName.replace(/,/g, ' '),
      o.totalPrice,
      o.paymentMethod,
      o.date
    ]);

    const csvContent = "data:text/csv;charset=utf-8," 
      + [headers.join(","), ...rows.map(e => e.join(","))].join("\n");
    
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `Pure_Honey_BD_Orders_${new Date().toISOString().slice(0,10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto flex items-center justify-center p-4 font-sans">
      {/* Dimmed backdrop */}
      <div onClick={onClose} className="fixed inset-0 bg-[#1B3022]/40 backdrop-blur-md"></div>

      {/* Main Admin Box layout */}
      <div className="bg-[#FDFCF8] rounded-lg w-full max-w-5xl max-h-[85vh] md:max-h-[90vh] overflow-hidden shadow-xl relative border border-black/5 z-10 flex flex-col">
        
        {/* Header bar banner */}
        <div className="bg-[#1B3022] px-6 py-5 flex items-center justify-between text-[#FDFCF8] shrink-0 text-left border-b border-black/5">
          <div className="flex items-center gap-3">
            <span className="text-xl">🐝</span>
            <div>
              <h3 className="font-serif text-lg md:text-xl font-bold flex items-center gap-2 leading-none">
                <span>মধু বিক্রেতা ড্যাশবোর্ড ও সেটিংস</span>
                <span className="bg-emerald-800 text-[10px] font-sans font-bold px-2.5 py-0.5 rounded uppercase tracking-widest select-none leading-none">
                  Merchant Active
                </span>
              </h3>
              <p className="text-[10px] text-gray-300 font-sans mt-1.5 font-light">অর্ডার নিরীক্ষণ, CSV এক্সপোর্ট, এবং গুগল শিট ইন্টিগ্রেশন প্যানেল।</p>
            </div>
          </div>
          <button 
            onClick={onClose} 
            className="p-1.5 rounded bg-white/5 hover:bg-white/10 text-[#FDFCF8] border border-white/10 transition-all cursor-pointer shadow-xs"
          >
            <X size={16} />
          </button>
        </div>

        {/* Tab Links toggles */}
        <div className="bg-[#FDFCF8] border-b border-black/5 flex gap-4 px-6 py-2 shrink-0 select-none">
          {[
            { id: 'orders', label: `অর্ডারসমূহ (${orders.length})`, icon: '🛒' },
            { id: 'config', label: 'গুগল শিট কনফিগারেশন', icon: '⚙' },
            { id: 'guide', label: 'ইন্টিগ্রেশন গাইডলাইন', icon: '📚' }
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`py-2 px-3 text-xs md:text-sm font-bold transition-all border-b-2 cursor-pointer flex items-center gap-1.5 ${
                activeTab === tab.id
                  ? 'border-[#D4AF37] text-gray-950 font-extrabold'
                  : 'border-transparent text-gray-500 hover:text-gray-900 font-normal'
              }`}
            >
              <span>{tab.icon}</span>
              <span>{tab.label}</span>
            </button>
          ))}
        </div>

        {/* Tab Body Content Area (Scrollable) */}
        <div className="flex-1 overflow-y-auto p-6 text-left">
          
          {/* TAB 1: PLACED ORDERS LIST VIEW */}
          {activeTab === 'orders' && (
            <div className="flex flex-col h-full gap-4">
              <div className="flex items-center justify-between flex-wrap gap-2">
                <div className="flex flex-col text-left">
                  <h4 className="font-serif font-bold text-sm md:text-base text-gray-900">অর্ডার হিস্টোরি লগস</h4>
                  <p className="text-[10px] text-gray-400 font-sans font-light">প্লেস করা সকল টেস্ট ও কমার্শিয়াল অর্ডারের তালিকা (ব্রাউজারে সংরক্ষিত)</p>
                </div>

                <div className="flex gap-2 shrink-0">
                  <button
                    onClick={handleExportCSV}
                    disabled={orders.length === 0}
                    className="py-1.5 px-3 bg-[#FDFCF8] hover:bg-[#F5F1E6] text-gray-850 font-bold text-[10px] uppercase tracking-wider border border-black/10 rounded-lg flex items-center gap-1 disabled:opacity-40 disabled:pointer-events-none cursor-pointer h-9 transition-colors"
                  >
                    <Download size={13} />
                    <span>Excel CSV এক্সপোর্ট</span>
                  </button>
                  
                  <button
                    onClick={() => {
                      if (confirm("আপনি কি নিশ্চিতভাবে সব অর্ডার ডিলিট করতে চান? এটি রিভার্স করা যাবে না।")) {
                        onClearOrders();
                      }
                    }}
                    disabled={orders.length === 0}
                    className="py-1.5 px-3 bg-red-100 hover:bg-red-200 text-red-800 font-bold text-[10px] uppercase tracking-wider rounded-lg flex items-center gap-1 border border-red-300/30 disabled:opacity-40 disabled:pointer-events-none cursor-pointer h-9 transition-colors"
                  >
                    <Trash2 size={13} />
                    <span>লগ ক্লিয়ার করুন</span>
                  </button>
                </div>
              </div>

              {orders.length === 0 ? (
                <div className="py-20 flex flex-col items-center justify-center text-gray-400 border border-dashed border-black/10 rounded-lg bg-black/[0.01] select-none">
                  <Database size={44} strokeWidth={1} />
                  <p className="text-xs font-bold text-gray-500 mt-4 leading-normal">এখনো কোনো অর্ডার লগ পাওয়া যায়নি।</p>
                  <p className="text-[10px] text-gray-400 mt-1 font-light">ল্যান্ডিং পেজের অর্ডার ফর্মে গিয়ে টেস্ট অর্ডার দিন। লগে সাথে সাথে যুক্ত হয়ে যাবে!</p>
                </div>
              ) : (
                <div className="overflow-x-auto border border-black/5 rounded-lg bg-[#FDFCF8] shadow-xs font-sans text-xs">
                  <table className="w-full text-left border-collapse min-w-[700px]">
                    <thead>
                      <tr className="bg-[#F5F1E6] border-b border-black/5 text-[#111111] font-bold uppercase tracking-wider text-[10px]">
                        <th className="p-4 font-serif">অর্ডার আইডি</th>
                        <th className="p-4 font-serif">ক্রেতা</th>
                        <th className="p-4 font-serif">মোবাইল</th>
                        <th className="p-4 font-serif">পণ্যসমূহ</th>
                        <th className="p-4 font-serif">পেমেন্ট মেথড</th>
                        <th className="p-4 font-serif">সর্বমোট বিল</th>
                        <th className="p-4 font-serif">তারিখ ও সময়</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-black/5 font-medium text-gray-650">
                      {orders.map((order) => (
                        <tr key={order.id} className="hover:bg-[#F5F1E6]/50 transition-colors">
                          <td className="p-4 font-mono font-bold text-gray-900 select-all">{order.id}</td>
                          <td className="p-4 text-gray-800">{order.customerName}</td>
                          <td className="p-4 font-mono text-gray-800">{order.phone}</td>
                          <td className="p-4 truncate max-w-[160px]" title={order.productName}>{order.productName}</td>
                          <td className="p-4">
                            <span className="bg-[#F5F1E6] text-[#1B3022] border border-black/5 px-2.5 py-0.5 rounded text-[9px] uppercase font-bold tracking-widest">
                              {order.paymentMethod}
                            </span>
                          </td>
                          <td className="p-4 font-bold text-[#111111] font-mono">৳{order.totalPrice}</td>
                          <td className="p-4 text-[10px] text-gray-400 font-light">{order.date}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          )}

          {/* TAB 2: GOOGLE SHEETS SETUP URLS CONFIG */}
          {activeTab === 'config' && (
            <div className="max-w-2xl mx-auto flex flex-col gap-6 font-sans">
              <div className="text-left border-b border-black/5 pb-3">
                <h4 className="font-serif font-bold text-sm md:text-base text-gray-900 flex items-center gap-2">
                  <span>⚙</span> গুগল শিট লাইভ সিঙ্ক সেটিংস
                </h4>
                <p className="text-[10px] text-gray-400 mt-1 font-light">এখানে আপনার গুগল অ্যাপস স্ক্রিপ্ট ওয়েব অ্যাপের URL সংযুক্ত করুন, যাতে ল্যান্ডিং পেজে ক্রেতারা অর্ডার প্লেস করলে কাস্টমার ডিটেইলস স্বয়ংক্রিয়ভাবে আপনার গুগল শিটে জমা হয়ে যায়!</p>
              </div>

              <div className="bg-[#FDFCF8] p-6 rounded-lg border border-black/5 shadow-xs flex flex-col gap-4 text-left">
                <div className="flex flex-col text-left">
                  <label className="text-xs font-semibold text-gray-700 flex items-center gap-1.5 mb-1.5">
                    <span>🔗</span> গুগল অ্যাপস স্ক্রিপ্ট (Web App URL):
                  </label>
                  <input
                    type="url"
                    placeholder="https://script.google.com/macros/s/XXXXXX/exec"
                    value={inputUrl}
                    onChange={(e) => setInputUrl(e.target.value)}
                    className="w-full bg-black/[0.01] border border-black/10 focus:border-[#D4AF37] focus:ring-1 focus:ring-[#D4AF37] rounded-lg p-3 text-xs md:text-sm font-mono focus:outline-none transition-all"
                  />
                  <span className="text-[10px] text-gray-400 mt-1.5 font-light">মাস্টার ওয়েব-অ্যাপ ইউআরএলটি অবশ্যই সঠিকভাবে কপি করে এখানে সেভ করতে হবে।</span>
                </div>

                {isSaved && (
                  <div className="p-3 bg-emerald-50 text-emerald-800 text-xs font-semibold rounded border border-emerald-100 flex items-center gap-1.5">
                    <Check size={14} /> URL সফলভাবে সেভ ও এ্যাক্টিভ করা হয়েছে!
                  </div>
                )}

                <button
                  onClick={handleSaveUrl}
                  className="bg-black hover:bg-neutral-900 text-white border border-black font-semibold font-serif text-[10px] py-2.5 px-6 rounded-lg cursor-pointer flex items-center justify-center gap-1.5 transition-colors self-start h-10 mt-2 uppercase tracking-widest"
                >
                  <Save size={13} className="text-white" />
                  <span>URL সংরক্ষণ করুণ</span>
                </button>
              </div>

              {/* Technical Indicator Status block */}
              <div className="p-4 bg-[#F5F1E6]/60 rounded-lg border border-black/5 text-xs text-gray-500 flex flex-col gap-2 select-none">
                <p className="font-bold text-gray-900 flex items-center gap-1">
                  <span>💡</span> ইন্টিগ্রেশন স্ট্যাটাস লক:
                </p>
                <div className="flex items-center gap-2 mt-1">
                  <span className={`h-2.5 w-2.5 rounded-full ${sheetUrl ? 'bg-emerald-500 animate-pulse' : 'bg-amber-500'}`}></span>
                  <span className="font-bold text-gray-800">
                    {sheetUrl ? "লাইভ গুগল শিট সিঙ্ক এ্যাক্টিভ" : "লোকাল মোড সক্রিয় (URL দেওয়া নেই)"}
                  </span>
                </div>
                <p className="leading-relaxed mt-1 text-[11px] text-gray-500 font-light">
                  {sheetUrl 
                    ? `আপনার অর্ডার ফর্ম এখন সরাসরি ${sheetUrl.substring(25, 45)}... URL এ ডাটা পাঠাবে।` 
                    : "ইন্টিগ্রেশন করার পূর্ব পর্যন্ত সকল অর্ডার টেস্ট করার জন্য লোকাল ব্রাউজারে সংরক্ষিত হবে।"
                  }
                </p>
              </div>
            </div>
          )}

          {/* TAB 3: STEP BY STEP DOCUMENTATION GUIDE */}
          {activeTab === 'guide' && (
            <div className="max-w-3xl mx-auto flex flex-col gap-6 font-sans">
              
              <div className="text-left border-b border-black/5 pb-3">
                <h4 className="font-serif font-bold text-sm md:text-base text-gray-900 flex items-center gap-2">
                  <span>📚</span> গুগল শিট ইন্টিগ্রেশন সেটআপ গাইড
                </h4>
                <p className="text-[10px] text-gray-400 mt-1 font-light">৫ মিনিটে সম্পূর্ণ সিঙ্ক পদ্ধতিটি চালু করুন কোনো কোডিং ছাড়াই!</p>
              </div>

              {/* Setups timelines step list */}
              <div className="flex flex-col gap-4 text-left font-sans text-xs text-gray-600 leading-relaxed font-light">
                <div>
                  <h5 className="font-bold text-[#111111] text-sm flex items-center gap-1.5 mb-1.5 font-serif">
                    <span className="bg-[#D4AF37] text-white rounded-lg h-5 w-5 text-2xs flex items-center justify-center font-bold font-sans">1</span>
                    গুগল শিট তৈরি করুন:
                  </h5>
                  <p className="pl-6 text-gray-550">
                    আপনার গুগল ড্রাইভ থেকে একটি নতুন গুগল শীট (Google Sheet) খুলুন। শিটের নাম আপনার ইচ্ছামতো দিতে পারেন। শিটের ভেতরে কোনো কাজ করা লাগবে না, প্রোগ্রাম স্বয়ংক্রিয়ভাবে প্রথম সারিতে কলাম হেডার সাজিয়ে নেবে।
                  </p>
                </div>

                <div>
                  <h5 className="font-bold text-[#111111] text-sm flex items-center gap-1.5 mb-1.5 font-serif">
                    <span className="bg-[#D4AF37] text-white rounded-lg h-5 w-5 text-2xs flex items-center justify-center font-bold font-sans">2</span>
                    অ্যাপস স্ক্রিপ্ট ম্যানেজার ওপেন করুন:
                  </h5>
                  <p className="pl-6 text-gray-550">
                    গুগল শিটের ওপরের মেনু বার থেকে <strong>Extensions (এক্সটেনশন)</strong> এ ক্লিক করুন এবং সেখান থেকে <strong>Apps Script (অ্যাপস স্ক্রিপ্ট)</strong> এ ক্লিক করুন। এতে নতুন একটি কোড লেখার উইন্ডো ওপেন হবে।
                  </p>
                </div>

                <div>
                  <h5 className="font-bold text-[#111111] text-sm flex items-center gap-1.5 mb-1.5 font-serif">
                    <span className="bg-[#D4AF37] text-white rounded-lg h-5 w-5 text-2xs flex items-center justify-center font-bold font-sans">3</span>
                    নিচের কোডটি কপি করে বসান:
                  </h5>
                  <p className="pl-6 text-gray-550">
                    কোড উইন্ডোতে থাকা পূর্ববর্তী ডিফল্ট কোডটুকু মুছে দিন। এরপর নিচে দেওয়া ইন্টিগ্রেশন স্ক্রিপ্টটি ডানে থাকা কপি বাটনে ক্লিক করে কপি করে সম্পূর্ণ পেস্ট করুন এবং ওপরে থাকা <strong>Save</strong> আইকনে ক্লিক করে সেভ করুন।
                  </p>

                  {/* Copyable code wrapper box */}
                  <div className="mt-3 pl-6">
                    <div className="bg-zinc-90 w-full bg-neutral-900 text-neutral-100 rounded-lg p-4 font-mono text-[10px] sm:text-xs overflow-x-auto max-h-[220px] shadow-inner relative border border-neutral-950 select-none">
                      
                      <button
                        onClick={handleCopyCode}
                        className="absolute top-2 right-2 py-1.5 px-2.5 rounded bg-white/5 hover:bg-white/10 text-white font-sans text-2xs transition-colors border border-white/10 flex items-center gap-1 cursor-pointer"
                      >
                        {isCopied ? (
                          <>
                            <Check size={10} className="text-[#D4AF37]" />
                            <span>কপি হয়েছে!</span>
                          </>
                        ) : (
                          <>
                            <Copy size={10} />
                            <span>ಕೋಡ್ কপি</span>
                          </>
                        )}
                      </button>

                      <pre className="pr-12 text-left">{gasCode}</pre>
                    </div>
                  </div>
                </div>

                <div>
                  <h5 className="font-bold text-[#111111] text-sm flex items-center gap-1.5 mb-1.5 font-serif">
                    <span className="bg-[#D4AF37] text-white rounded-lg h-5 w-5 text-2xs flex items-center justify-center font-bold font-sans">4</span>
                    ওয়েব অ্যাপ হিসেবে রিলিজ ও অনুমতি দিন (Deploy):
                  </h5>
                  <p className="pl-6 text-gray-550">
                    কোড উইন্ডোর ওপরের ডানে থাকা <strong>Deploy (ডিপ্লয়)</strong> বাটনে ক্লিক করে <strong>New Deployment</strong> সিলেক্ট করুন। <br />
                    - বাম পাশে থাকা সেটিং গিয়ার আইকন থেকে <strong>Web app (ওয়েব অ্যাপ)</strong> অপশন সিলেক্ট করুন। <br />
                    - <strong>Execute as</strong> ঘরটিতে <strong>Me</strong> সিলেক্ট করবেন। <br />
                    - <strong>Who has access</strong> ঘরটিতে অবশ্যই <strong>Anyone (যেকোনো ব্যক্তি)</strong> সিলেক্ট করতে হবে (নতুবা ডাটা জমা হবে না)। <br />
                    - এরপর <strong>Deploy</strong> এ প্রেস করে গুগল অ্যাকাউন্টের অ্যাক্সেস অনুমতি (Authorize) দিন।
                  </p>
                </div>

                <div>
                  <h5 className="font-bold text-[#111111] text-sm flex items-center gap-1.5 mb-1.5 font-serif">
                    <span className="bg-[#D4AF37] text-white rounded-lg h-5 w-5 text-2xs flex items-center justify-center font-bold font-sans">5</span>
                    ওয়েব অ্যাপ URL কপি ও পেস্ট করুন:
                  </h5>
                  <p className="pl-6 text-gray-550">
                    সফলভাবে ডিপ্লয় সম্পন্ন হলে গুগল একটি দীর্ঘ <strong>Web App URL</strong> প্রদান করবে। সেই URL-টি কপি করে এনে আমাদের ড্যাশবোর্ডের <strong>&quot;গুগল শিট কনফিগারেশন&quot;</strong> ট্যাবে পেস্ট করে সেভ করুন। ব্যস! আপনার লাইভ সিঙ্ক পদ্ধতি চালু!
                  </p>
                </div>

              </div>

            </div>
          )}

        </div>

      </div>
    </div>
  );
}
