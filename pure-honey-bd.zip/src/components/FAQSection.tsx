import { useState } from 'react';
import { FAQS } from '../data';
import { ChevronDown, Search } from 'lucide-react';

export default function FAQSection() {
  const [openId, setOpenId] = useState<string | null>("faq1");
  const [searchQuery, setSearchQuery] = useState("");

  const handleToggle = (id: string) => {
    setOpenId(openId === id ? null : id);
  };

  const filteredFaqs = FAQS.filter(f => 
    f.question.toLowerCase().includes(searchQuery.toLowerCase()) ||
    f.answer.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <section id="faq" className="py-20 bg-[#FDFCF8] relative">
      <span className="hidden">Pure Honey BD Common Frequently Asked Questions</span>
      
      {/* Light honey yellow accent balls */}
      <div className="absolute top-[15%] right-[-10%] w-[250px] h-[250px] bg-[#D4AF37]/5 rounded-full blur-3xl pointer-events-none"></div>

      <div className="max-w-7xl mx-auto px-4 md:px-6 lg:px-8">
        
        {/* Section Title */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="inline-flex items-center gap-1.5 bg-[#1B3022]/10 text-[#1B3022] px-4 py-1.5 rounded-full text-[10px] font-bold uppercase tracking-[0.2em] mb-3 select-none">
            <span>❓</span> জিজ্ঞাসা ও সাধারণ উত্তরসমূহ
          </div>
          <h2 className="font-serif text-3xl md:text-4xl lg:text-5xl text-[#111111] font-semibold tracking-tight leading-tight">
            সাধারণ জিজ্ঞাসা ও সাহায্য বোর্ড
          </h2>
          <div className="h-[1.5px] w-24 bg-[#D4AF37] mx-auto mt-4"></div>
          <p className="font-sans text-sm text-gray-500 mt-5 leading-relaxed font-light">
            মধুর গুণাগুণ ও বোতলজাতকরণ নিয়ে গ্রাহকদের সচরাচর করা প্রশ্নগুলোর সঠিক যুক্তিযুক্ত ও বৈজ্ঞানিক ভিত্তিতে সহজ উত্তর নিচে দেওয়া হলো।
          </p>
        </div>

        {/* Micro FAQ Search Bar */}
        <div className="max-w-md mx-auto mb-10 select-none relative">
          <input
            type="text"
            placeholder="আপনার কাঙ্ক্ষিত প্রশ্নটি খুঁজুন..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-[#FDFCF8] border border-black/10 focus:border-[#D4AF37] focus:ring-1 focus:ring-[#D4AF37] rounded-lg py-3 pl-11 pr-4 text-xs md:text-sm focus:outline-none transition-all"
          />
          <Search size={16} className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400" />
        </div>

        {/* Split Grid: Left side trust indicators, Right side FAQ accordions */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-start max-w-5xl mx-auto">
          
          {/* Left panel metrics (5 cols) */}
          <div className="lg:col-span-5 bg-[#F5F1E6] p-6 md:p-8 rounded-lg border border-black/5 shadow-sm text-left select-none">
            <h3 className="font-serif text-lg font-bold text-[#111111] flex items-center gap-1.5 leading-tight">
              <span>🛡</span> ১০০% ক্যাশব্যাক অফার ও গ্যারান্টি!
            </h3>
            
            <p className="text-xs md:text-sm text-gray-500 mt-3 leading-relaxed font-light">
              যদি কোনো ল্যাব টেস্ট দ্বারা আমাদের মধু কৃত্রিম, ভেজাল অথবা সুগার সিরাপ মিশ্রিত প্রমাণিত হয় তবে আমরা দ্বিগুণ ক্ষতিপূরণসহ গ্রাহকদের সম্পূর্ণ পেমেন্ট ফেরত দিতে আইনিভাবে দায়বদ্ধ।
            </p>

            <hr className="my-5 border-black/5" />

            <div className="flex flex-col gap-4">
              <div className="flex items-center gap-3">
                <div className="h-8 w-8 bg-[#FDFCF8] text-[#1B3022] rounded border border-black/5 flex items-center justify-center font-bold shadow-xs">✓</div>
                <div className="flex flex-col">
                  <span className="font-bold text-xs text-[#111111]">ফুড-গ্রেড ডাস্ট ফিল্টার করা জার</span>
                  <span className="text-[10px] text-gray-400 font-light">কোনো প্রকার হাই-থার্মাল প্রসেসিং বিদায়</span>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <div className="h-8 w-8 bg-[#FDFCF8] text-[#D4AF37] rounded border border-black/5 flex items-center justify-center font-bold shadow-xs">✓</div>
                <div className="flex flex-col">
                  <span className="font-bold text-xs text-[#111111]">মৌমাছিদের চিনি খাওয়ানো হয় না</span>
                  <span className="text-[10px] text-gray-400 font-light">শতভাগ প্রাকৃতিক ফুলে নেক্টার সংগ্রহ</span>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <div className="h-8 w-8 bg-[#FDFCF8] text-emerald-700 rounded border border-black/5 flex items-center justify-center font-bold shadow-xs">✓</div>
                <div className="flex flex-col">
                  <span className="font-bold text-xs text-[#111111]">সারাদেশে নির্ভরযোগ্য হোম ডেলিভারি</span>
                  <span className="text-[10px] text-gray-400 font-light">পণ্য হাতে পেয়ে চেক করে টাকা দিন</span>
                </div>
              </div>
            </div>
          </div>

          {/* Right panel FAQ Accordions (7 cols) */}
          <div className="lg:col-span-7 flex flex-col gap-3 max-w-full">
            {filteredFaqs.length === 0 ? (
              <div className="py-12 bg-[#FDFCF8] rounded-lg text-center border border-black/5 text-gray-400 text-xs font-light">
                কোনো প্রশ্ন পাওয়া যায়নি। দয়া করে ভিন্ন নামে খুঁজুন।
              </div>
            ) : (
              filteredFaqs.map((faq) => {
                const isOpen = openId === faq.id;
                return (
                  <div
                    key={faq.id}
                    className="bg-[#FDFCF8] rounded-lg border border-black/5 hover:border-[#D4AF37] transition-all duration-300 shadow-xs relative overflow-hidden"
                  >
                    {/* Header item button */}
                    <button
                      onClick={() => handleToggle(faq.id)}
                      className="w-full p-4 md:p-5 flex justify-between items-center text-left gap-4 font-serif font-extrabold text-sm md:text-base text-gray-900 focus:outline-none cursor-pointer"
                    >
                      <span className="flex items-center gap-2">
                        <span className="text-[#D4AF37] text-sm hidden sm:inline">●</span>
                        <span className="hover:text-[#D4AF37] transition-colors leading-snug">{faq.question}</span>
                      </span>
                      <ChevronDown 
                        size={18} 
                        className={`text-gray-400 shrink-0 transform transition-transform duration-300 ${
                          isOpen ? 'rotate-180 text-[#D4AF37]' : ''
                        }`} 
                      />
                    </button>

                    {/* Collapsible details text bodies with height smooth */}
                    <div 
                      className={`transition-all duration-300 ease-in-out font-sans ${
                        isOpen 
                          ? 'max-h-[300px] border-t border-black/5 bg-[#F5F1E6]/30 opacity-100 p-4 md:p-5 text-left' 
                          : 'max-h-0 pointer-events-none opacity-0 overflow-hidden'
                      }`}
                    >
                      <p className="text-xs sm:text-sm text-gray-500 leading-relaxed font-light">
                        {faq.answer}
                      </p>
                    </div>

                  </div>
                );
              })
            )}
          </div>

        </div>

      </div>
    </section>
  );
}
