import { BENEFITS_ITEMS } from '../data';
import { ShieldCheck, Ban, Users, Heart, Zap, RotateCcw, Award } from 'lucide-react';

export default function BenefitsSection() {
  
  // Icon mapper helper
  const getIcon = (iconName: string) => {
    switch (iconName) {
      case "ShieldCheck":
        return <ShieldCheck size={28} className="text-amber-600" />;
      case "Ban":
        return <Ban size={28} className="text-red-500" />;
      case "Users":
        return <Users size={28} className="text-[#059669]" />;
      case "Heart":
        return <Heart size={28} className="text-rose-500" fill="currentColor" />;
      case "Zap":
        return <Zap size={28} className="text-amber-500" fill="currentColor" />;
      case "RotateCcw":
        return <RotateCcw size={28} className="text-blue-500" />;
      default:
        return <Award size={28} className="text-amber-600" />;
    }
  };

  return (
    <section id="benefits" className="py-20 bg-[#F5F1E6] relative overflow-hidden">
      <span className="hidden">Pure Honey BD Benefits and Characteristics</span>
      
      {/* Dynamic ambient lights decorations */}
      <div className="absolute top-[20%] right-[-10%] w-[400px] h-[400px] bg-[#D4AF37]/5 rounded-full blur-3xl -z-10 animate-beam"></div>
      <div className="absolute bottom-[10%] left-[-10%] w-[400px] h-[400px] bg-[#1B3022]/5 rounded-full blur-3xl -z-10 animate-pulse"></div>

      <div className="max-w-7xl mx-auto px-4 md:px-6 lg:px-8 relative z-20">
        
        {/* Section Heading */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="inline-flex items-center gap-1.5 bg-[#1B3022]/10 text-[#1B3022] px-4 py-1.5 rounded-full text-[10px] font-bold uppercase tracking-[0.2em] mb-3 select-none">
            <span>🎗</span> আস্থার বিশ্বস্ত নাম
          </div>
          <h2 className="font-serif text-3xl md:text-4xl lg:text-5xl text-[#111111] font-semibold tracking-tight leading-tight">
            কেন আমাদের ওপর চোখ বন্ধ করে <br />
            <span className="text-[#1B3022] font-semibold">
              ভরসা রাখবেন?
            </span>
          </h2>
          <div className="h-[1.5px] w-24 bg-[#D4AF37] mx-auto mt-4"></div>
          <p className="font-sans text-sm text-gray-500 mt-5 leading-relaxed font-light">
            বাজারের কমদামী কৃত্রিম ও ভেজাল মধুর ভিড়ে 'Pure Honey BD' আপনাকে দিচ্ছে শতভাগ খাঁটি এবং প্রাকৃতিক পুষ্টির প্রতিশ্রুতি। আমরা মধুর প্রতিটি ফোটাতে সর্বোচ্চ গুণ বজায় রাখি।
          </p>
        </div>

        {/* Honeycomb Card Layout Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 md:gap-6 lg:gap-8">
          {BENEFITS_ITEMS.map((item, index) => (
            <div
              key={index}
              className="bg-[#FDFCF8] rounded-lg p-6 md:p-8 border border-black/5 hover:border-[#D4AF37] shadow-sm hover:shadow-md transition-all duration-300 group flex flex-col justify-between"
            >
              <div className="text-left">
                
                {/* Glowing dynamic gradient icon backing */}
                <div className="h-12 w-12 rounded bg-black/[0.03] border border-black/5 flex items-center justify-center mb-6 group-hover:scale-102 transition-transform">
                  {getIcon(item.icon)}
                </div>

                <h3 className="font-serif text-lg font-bold text-gray-900 leading-snug">
                  {item.title}
                </h3>

                <p className="font-sans text-xs md:text-sm text-gray-400 mt-3 leading-relaxed font-light">
                  {item.desc}
                </p>

              </div>

              {/* Bottom decorative vector indicator */}
              <div className="flex justify-end mt-4">
                <span className="text-[#D4AF37]/20 group-hover:text-[#D4AF37]/50 font-mono text-xl font-bold transition-colors select-none">
                  0{index + 1}
                </span>
              </div>
            </div>
          ))}
        </div>

        {/* Honeycomb visual graphic callout */}
        <div className="mt-16 text-center select-none opacity-20">
          <span className="text-xl tracking-[0.3em]">🍯 🐝 🌻 🍯 🐝 🌻</span>
        </div>

      </div>
    </section>
  );
}
