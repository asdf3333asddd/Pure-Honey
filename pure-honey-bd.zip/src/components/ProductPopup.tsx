import { useState } from 'react';
import { Product } from '../types';
import { X, Check, ShoppingBag, ShieldCheck, Truck, RefreshCw } from 'lucide-react';

interface ProductPopupProps {
  product: Product | null;
  onClose: () => void;
  onAddToCart: (product: Product, weight: string, price: number, quantity: number) => void;
  onDirectCheckout: (product: Product, weight: string, price: number, quantity: number) => void;
}

export default function ProductPopup({ product, onClose, onAddToCart, onDirectCheckout }: ProductPopupProps) {
  if (!product) return null;

  // Selected weight options index tracking inside the modal
  const [selectedWeightIdx, setSelectedWeightIdx] = useState(0);
  const [quantity, setQuantity] = useState(1);
  const [isAdded, setIsAdded] = useState(false);

  const activeOption = product.weightOptions[selectedWeightIdx];
  const activePrice = activeOption.discountPrice || activeOption.price;
  const originalPrice = activeOption.price;

  const incrementQty = () => setQuantity(prev => prev + 1);
  const decrementQty = () => setQuantity(prev => (prev > 1 ? prev - 1 : 1));

  const handleAddToCart = () => {
    onAddToCart(product, activeOption.weight, activePrice, quantity);
    setIsAdded(true);
    setTimeout(() => {
      setIsAdded(false);
    }, 2000);
  };

  const handleCheckoutNow = () => {
    onDirectCheckout(product, activeOption.weight, activePrice, quantity);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto flex items-center justify-center p-4 font-sans">
      {/* Background Dimming Layer with blur */}
      <div 
        onClick={onClose}
        className="fixed inset-0 bg-[#1B3022]/40 backdrop-blur-md transition-opacity"
      ></div>

      {/* Main Modal Layout Card Container */}
      <div className="bg-[#FDFCF8] rounded-lg w-full max-w-4xl max-h-[85vh] md:max-h-[90vh] overflow-y-auto shadow-xl relative border border-black/5 z-10 animate-fade-in flex flex-col">
        
        {/* Top header action row */}
        <div className="sticky top-0 right-0 p-4 md:p-6 flex justify-end items-center bg-gradient-to-b from-[#FDFCF8] via-[#FDFCF8]/85 to-transparent z-20 pointer-events-none">
          <button
            onClick={onClose}
            className="p-2 rounded bg-[#FDFCF8] hover:bg-[#F5F1E6] text-gray-500 hover:text-gray-900 border border-black/10 pointer-events-auto transition-transform active:scale-95 cursor-pointer shadow-xs"
          >
            <X size={18} />
          </button>
        </div>

        {/* Modal content body split grid */}
        <div className="grid grid-cols-1 md:grid-cols-12 gap-8 px-6 md:px-8 pb-10">
          
          {/* Left Column: Premium Interactive Product Display */}
          <div className="md:col-span-5 flex flex-col gap-4">
            <div className="w-full aspect-square rounded-lg bg-[#FAF6ED] border border-black/5 overflow-hidden relative shadow-inner">
              <img 
                src={product.image} 
                alt={product.name} 
                className="w-full h-full object-cover transform duration-500 hover:scale-102"
                referrerPolicy="no-referrer"
              />
              {/* Highlight badge for organic category */}
              <div className="absolute top-4 left-4 bg-[#1B3022] text-[#FDFCF8] font-sans font-bold text-[9px] uppercase tracking-widest px-2.5 py-1 rounded-sm shadow-xs mb-3">
                ORGANIC GRADE A
              </div>
            </div>

            {/* Scientific Details / Origin specifications list */}
            <div className="bg-[#F5F1E6] rounded-lg border border-black/5 p-4 font-sans text-xs text-left leading-relaxed text-gray-650 flex flex-col gap-2">
              <div className="flex justify-between border-b border-black/5 pb-1.5">
                <span className="font-bold text-gray-400 uppercase tracking-wilder text-[10px]">বৈজ্ঞানিক তথ্য:</span>
                <span className="font-bold text-gray-800 font-mono text-[11px]">{product.scientificName || "Raw Pure Honey"}</span>
              </div>
              <div className="flex justify-between border-b border-black/5 pb-1.5">
                <span className="font-bold text-gray-400 uppercase tracking-wilder text-[10px]">সংগ্রহক্ষেত্র:</span>
                <span className="font-bold text-gray-800">{product.harvestArea}</span>
              </div>
              <div className="flex justify-between border-b border-black/5 pb-1.5">
                <span className="font-bold text-gray-400 uppercase tracking-wilder text-[10px]">স্বাদের ধরন:</span>
                <span className="font-bold text-gray-800 italic">{product.tasteProfile}</span>
              </div>
              <div className="flex justify-between">
                <span className="font-bold text-gray-400 uppercase tracking-wilder text-[10px]">উপযোগিতা:</span>
                <span className="font-bold text-gray-800">{product.bestFor}</span>
              </div>
            </div>
          </div>

          {/* Right Column: Key description, weight inputs, pricing actions */}
          <div className="md:col-span-7 flex flex-col text-left justify-between">
            <div>
              {/* Star review verification */}
              <div className="flex items-center gap-1 text-amber-500 select-none">
                <div className="flex">★★★★★</div>
                <span className="text-xs font-bold text-gray-700 ml-1">({product.rating} / 5.0)</span>
                <span className="text-black/10 font-sans text-xs mx-1.5">|</span>
                <span className="text-[#1B3022] font-bold text-[9px] uppercase tracking-widest flex items-center gap-1 bg-[#1B3022]/10 px-2 py-0.5 rounded border border-black/5">
                  <ShieldCheck size={11} /> Verified Premium
                </span>
              </div>

              {/* Title headlines */}
              <h3 className="font-serif text-2xl md:text-3xl font-semibold text-[#111111] mt-2 leading-tight">{product.name}</h3>
              <p className="font-sans text-xs text-[#D4AF37] font-bold italic mt-0.5 tracking-wide">{product.englishName}</p>

              {/* Comprehensive Description text */}
              <p className="font-sans text-xs sm:text-sm text-gray-500 mt-4 leading-relaxed font-light">{product.longDescription}</p>

              {/* Split key benefits bullets list */}
              <div className="mt-5 border-t border-black/5 pt-4">
                <h4 className="font-serif text-xs md:text-sm font-bold text-[#111111] flex items-center gap-1">
                  <span>🐝</span> মধুর প্রধান ওষধি উপকারিতাসমূহ:
                </h4>
                <ul className="grid grid-cols-1 md:grid-cols-2 gap-2 mt-2.5">
                  {product.benefits.map((b, i) => (
                    <li key={i} className="flex items-start gap-1.5 text-xs text-gray-500 font-light leading-normal">
                      <span className="text-emerald-700 font-bold">✓</span>
                      <span>{b}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Interactive Weight Selection Panel */}
              <div className="mt-6 border-t border-black/5 pt-4 flex flex-col select-none">
                <span className="text-[10px] text-gray-400 font-bold uppercase tracking-widest">পছন্দসই মধুর সাইজ ও ওজন বেছে নিন:</span>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 mt-2 max-w-sm">
                  {product.weightOptions.map((opt, i) => (
                    <button
                      key={opt.weight}
                      onClick={() => setSelectedWeightIdx(i)}
                      className={`py-2 px-3 rounded-lg border flex flex-col items-center justify-center transition-all cursor-pointer ${
                        selectedWeightIdx === i
                          ? 'bg-[#F5F1E6] text-[#1B3022] border-[#D4AF37] font-bold shadow-xs'
                          : 'bg-black/[0.01] text-gray-600 border-black/5 hover:border-black/10'
                      }`}
                    >
                      <span className="text-xs md:text-sm font-semibold">{opt.weight}</span>
                      <span className="text-[10px] font-bold text-[#D4AF37] font-mono mt-0.5">
                        ৳{opt.discountPrice || opt.price}
                      </span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Quantity selectors combined with details */}
              <div className="mt-6 flex flex-col border-t border-black/5 pt-4 select-none">
                <span className="text-[10px] text-gray-400 font-bold uppercase tracking-widest">পরিমাণ / পিস (প্যাক):</span>
                <div className="flex items-center gap-4 mt-2">
                  <div className="flex items-center border border-black/10 rounded-lg p-0.5 bg-black/[0.01] h-10 w-28 justify-between">
                    <button 
                      onClick={decrementQty}
                      className="w-8 h-8 text-gray-650 hover:bg-[#F5F1E6] active:scale-90 font-bold flex items-center justify-center rounded cursor-pointer"
                    >
                      -
                    </button>
                    <span className="text-xs font-bold text-gray-800 font-mono">{quantity}</span>
                    <button 
                      onClick={incrementQty}
                      className="w-8 h-8 text-gray-650 hover:bg-[#F5F1E6] active:scale-90 font-bold flex items-center justify-center rounded cursor-pointer"
                    >
                      +
                    </button>
                  </div>
                  <span className="text-[11px] text-gray-400 font-sans italic font-light">স্টক অত্যন্ত সীমিত! দ্রুত অর্ডার করুন।</span>
                </div>
              </div>

            </div>

            {/* Bottom Actions footer box */}
            <div className="mt-8 border-t border-black/5 pt-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              
              {/* Dynamic calculations values */}
              <div className="text-left font-sans">
                <span className="text-[10px] text-gray-400 tracking-wider">সর্বমোট আনুমানিক মূল্য:</span>
                <div className="flex items-baseline gap-1.5 mt-0.5">
                  <span className="font-sans font-bold text-[#111111] text-2xl md:text-3xl font-mono leading-none">৳{activePrice * quantity}</span>
                  {activeOption.discountPrice && (
                    <span className="text-xs text-gray-400 line-through font-mono">৳{originalPrice * quantity}</span>
                  )}
                </div>
              </div>

              {/* Combined Cart / Buy Now buttons */}
              <div className="flex gap-2 w-full sm:w-auto">
                <button
                  onClick={handleAddToCart}
                  className={`flex-1 sm:flex-none py-3 px-6 rounded-lg border font-bold text-xs transition-all flex items-center justify-center gap-1.5 active:scale-95 cursor-pointer h-12 uppercase tracking-widest ${
                    isAdded
                      ? 'bg-emerald-100 text-emerald-800 border-emerald-200'
                      : 'bg-[#FDFCF8] text-gray-800 border-black/10 hover:border-black'
                  }`}
                >
                  {isAdded ? (
                    <>
                      <Check size={15} className="text-emerald-800" />
                      <span>যোগ হয়েছে!</span>
                    </>
                  ) : (
                    <>
                      <ShoppingBag size={14} className="text-emerald-700" />
                      <span>কার্টে রাখুন</span>
                    </>
                  )}
                </button>

                <button
                  onClick={handleCheckoutNow}
                  className="flex-1 sm:flex-none bg-[#111111] hover:bg-[#222222] text-[#FDFCF8] border border-black font-semibold font-serif text-[10px] py-3 px-8 rounded-lg outline-none active:scale-95 cursor-pointer flex items-center justify-center gap-1.5 h-12 uppercase tracking-widest transition-colors duration-300"
                >
                  <span>অর্ডার কনফার্ম করুন</span>
                </button>
              </div>

            </div>

            {/* Quick Guarantees bar */}
            <div className="grid grid-cols-3 gap-2 border-t border-black/5 pt-4 mt-4 text-[10px] text-gray-450 font-sans text-center font-light">
              <span className="flex items-center justify-center gap-1 text-gray-500"><Truck size={12} className="text-[#D4AF37]" /> সারা দেশব্যাপী হোম ডেলিভারি</span>
              <span className="flex items-center justify-center gap-1 text-gray-500"><RefreshCw size={12} className="text-emerald-700" /> ৭ দিন রিটার্ন পলিসি গ্যারান্টি</span>
              <span className="flex items-center justify-center gap-1 text-gray-500"><ShieldCheck size={12} className="text-rose-7001 text-emerald-700" /> বিশুদ্ধতার শতভাগ নিশ্চয়তা</span>
            </div>

          </div>

        </div>
      </div>
    </div>
  );
}
