import { useState, useEffect } from 'react';
import { Smartphone, Sparkles, Shield, Gift, ChevronRight } from 'lucide-react';

interface AnnouncementBarProps {
  onOpenAdmin: () => void;
  orderCount: number;
}

export default function AnnouncementBar({ onOpenAdmin, orderCount }: AnnouncementBarProps) {
  const [currentPromoIndex, setCurrentPromoIndex] = useState(0);

  const announcements = [
    "🐝 ১০০% খাঁটি প্রাকৃতিক সুন্দরবন ও কালোজিরা মধু সরাসরি খামার থেকে সংগৃহীত।",
    "📦 অফার: দুই বা ততোধিক কেজি অর্ডারে সারা দেশে কুরিয়ার চার্জ একদম ফ্রি!",
    "🤝 নির্ভরযোগ্য ক্যাশ অন ডেলিভারি (COD) সুবিধা সারা বাংলাদেশে।"
  ];

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentPromoIndex((prev) => (prev + 1) % announcements.length);
    }, 5000);
    return () => clearInterval(interval);
  }, [announcements.length]);

  return (
    <div id="announcement-bar" className="bg-[#1B3022] text-[#FCFBF7]/90 font-sans text-[11px] tracking-widest uppercase border-b border-white/5 h-10 relative overflow-hidden flex items-center justify-between px-6 z-50">
      {/* Absolute background accent line */}
      <div className="absolute top-0 left-0 w-full h-[1px] bg-gradient-to-r from-transparent via-[#D4AF37] to-transparent"></div>

      {/* Static left tag */}
      <div className="hidden md:flex items-center gap-2 text-[#D4AF37] font-bold">
        <span className="flex h-1.5 w-1.5 relative">
          <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-[#D4AF37] opacity-75"></span>
          <span className="relative inline-flex rounded-full h-1.5 w-1.5 bg-[#D4AF37]"></span>
        </span>
        <span>SUPER ORGANIC</span>
      </div>

      {/* Middle Animated Marquee / Slideshow */}
      <div className="flex-1 max-w-xl mx-auto overflow-hidden relative">
        <div className="w-full flex justify-center text-center font-medium">
          <div className="animate-fade-in flex items-center gap-1 text-[11px] md:text-xs">
            {announcements[currentPromoIndex]}
          </div>
        </div>
      </div>

      {/* Right Action buttons - Includes Admin Portal & Support Number */}
      <div className="flex items-center gap-4 text-[10px] md:text-xs font-semibold">
        <a href="tel:+8801700000000" className="hidden lg:flex items-center gap-1 text-gray-300 hover:text-[#D4AF37] transition-colors">
          <Smartphone size={12} className="text-[#D4AF37]" />
          <span>+8801700-000000</span>
        </a>
        
        <button 
          id="admin-dashboard-trigger"
          onClick={onOpenAdmin} 
          className="flex items-center gap-1.5 bg-[#D4AF37]/15 hover:bg-[#D4AF37]/25 text-[#D4AF37] border border-[#D4AF37]/35 px-2 py-0.5 rounded-full text-2xs md:text-[11px] transition-all"
          title="Seller Admin Panel & Sheet Settings"
        >
          <span className="relative flex h-1.5 w-1.5 mr-0.5">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-[#D4AF37] opacity-75"></span>
            <span className="relative inline-flex rounded-full h-1.5 w-1.5 bg-[#D4AF37]"></span>
          </span>
          <span>সেলার ড্যাশবোর্ড {orderCount > 0 && `(${orderCount})`}</span>
          <ChevronRight size={10} />
        </button>
      </div>
    </div>
  );
}
