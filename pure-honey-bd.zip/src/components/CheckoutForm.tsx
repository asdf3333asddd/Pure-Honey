import { useState, FormEvent } from 'react';
import { CartItem, PaymentMethod, OrderInput } from '../types';
import { ShoppingBag, Check, Loader, ShieldAlert } from 'lucide-react';

interface CheckoutFormProps {
  cartItems: CartItem[];
  onRemoveFromCart: (idx: number) => void;
  onClearCart: () => void;
  onSubmitOrder: (order: OrderInput) => Promise<{ success: boolean; orderId?: string; error?: string }>;
  sheetUrl: string;
}

export default function CheckoutForm({ cartItems, onRemoveFromCart, onClearCart, onSubmitOrder }: CheckoutFormProps) {
  
  // Checkout Form fields
  const [customerName, setCustomerName] = useState('');
  const [phone, setPhone] = useState('');
  const [address, setAddress] = useState('');
  const [selectedPayment, setSelectedPayment] = useState<PaymentMethod>(PaymentMethod.COD);
  
  // Specific payment account / TxID info
  const [paymentNumber, setPaymentNumber] = useState('');
  const [transactionId, setTransactionId] = useState('');

  // Shipping location toggle to calculate delivery charge
  const [shippingLocation, setShippingLocation] = useState<'inside-dhaka' | 'outside-dhaka'>('inside-dhaka');

  // Order placing statuses
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [successOrder, setSuccessOrder] = useState<any>(null);
  const [errorMessage, setErrorMessage] = useState('');

  // Auto-validate field states
  const [fieldErrors, setFieldErrors] = useState<Record<string, string>>({});

  // Helper quantities & weight estimations
  const totalQty = cartItems.reduce((acc, item) => acc + item.quantity, 0);
  
  // Check if eligible for free shipping: total weight >= 1kg (1000g) OR total items >= 2
  const isEligibleForFreeShipping = (() => {
    if (totalQty >= 2) return true;
    
    // Estimate total grams
    let totalGrams = 0;
    cartItems.forEach(item => {
      const weightStr = item.selectedWeight.toLowerCase();
      let grams = 250;
      if (weightStr.includes('500g') || weightStr.includes('৫০০')) grams = 500;
      else if (weightStr.includes('1kg') || weightStr.includes('১')) grams = 1000;
      totalGrams += (grams * item.quantity);
    });
    return totalGrams >= 1000;
  })();

  const deliveryCharge = isEligibleForFreeShipping 
    ? 0 
    : (shippingLocation === 'inside-dhaka' ? 60 : 130);

  const cartSubtotal = cartItems.reduce((acc, item) => acc + (item.selectedPrice * item.quantity), 0);
  const orderTotalPrice = cartSubtotal + deliveryCharge;

  // Real-time phone check selector
  const validatePhone = (number: string) => {
    // Bangladesh mobile regex starts with 013-019 and has exact 11 digits
    const regex = /^(013|014|015|016|017|018|019)\d{8}$/;
    return regex.test(number);
  };

  const handleConfirmOrder = async (e: FormEvent) => {
    e.preventDefault();
    setErrorMessage('');
    
    // Validate inputs
    const errors: Record<string, string> = {};
    if (!customerName.trim()) {
      errors.customerName = "দয়া করে আপনার নাম লিখুন";
    }
    if (!phone) {
      errors.phone = "মোবাইল নম্বর দেওয়া আবশ্যক";
    } else if (!validatePhone(phone)) {
      errors.phone = "১১ ডিজিটের সঠিক বিডি মোবাইল নম্বরটি লিখুন (যেমন: 01712345678)";
    }
    if (!address.trim()) {
      errors.address = "দয়া করে পণ্য পাওয়ার পূর্ণাঙ্গ ঠিকানাটি লিখুন";
    }

    if (Object.keys(errors).length > 0) {
      setFieldErrors(errors);
      // Scroll to checkout form context block
      const element = document.getElementById("checkout-form-container");
      if (element) {
        element.scrollIntoView({ behavior: 'smooth' });
      }
      return;
    }

    setFieldErrors({});
    setIsSubmitting(true);

    try {
      // Package product summary for spreadsheets
      const productNames = cartItems.map(item => `${item.product.name} (${item.selectedWeight}) x${item.quantity}`).join(', ');
      
      const payload: OrderInput = {
        customerName,
        phone,
        address: `${address} (${shippingLocation === 'inside-dhaka' ? "ঢাকার ভেতরে" : "ঢাকার বাইরে"})`,
        productId: cartItems.map(item => item.product.id).join(','),
        productName: productNames,
        weight: cartItems.map(item => item.selectedWeight).join(','),
        quantity: totalQty,
        totalPrice: orderTotalPrice,
        paymentMethod: selectedPayment,
        paymentNumber: selectedPayment !== PaymentMethod.COD ? paymentNumber : undefined,
        transactionId: selectedPayment !== PaymentMethod.COD ? transactionId : undefined,
      };

      const res = await onSubmitOrder(payload);
      
      if (res.success) {
        setSuccessOrder({
          orderId: res.orderId,
          customerName,
          phone,
          address,
          productName: productNames,
          totalPrice: orderTotalPrice,
          paymentMethod: selectedPayment,
          deliveryCharge
        });
        onClearCart();
      } else {
        setErrorMessage(res.error || "অর্ডার প্লেস করা সম্ভব হয়নি। পুনরায় চেষ্টা করুন বা হোয়াটসঅ্যাপ করুন।");
      }
    } catch (err: any) {
      setErrorMessage("কোনো সংযোগের সমস্যা দেখা দিয়েছে। দয়া করে ইন্টারনেট চেক করুন।");
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleResetCheckout = () => {
    setSuccessOrder(null);
    setCustomerName('');
    setPhone('');
    setAddress('');
    setPaymentNumber('');
    setTransactionId('');
    setSelectedPayment(PaymentMethod.COD);
  };

  // Successful invoice rendering
  if (successOrder) {
    return (
      <div id="checkout-section" className="py-20 bg-[#FDFCF8] min-h-[70vh] flex items-center justify-center relative font-sans">
        <span className="hidden">Pure Honey BD Successful Invoice Receipt</span>
        <div className="absolute top-[10%] left-[10%] text-5xl opacity-10 pointer-events-none">🎉</div>
        <div className="absolute bottom-[20%] right-[10%] text-5xl opacity-10 pointer-events-none">🐝</div>

        <div className="max-w-xl w-full mx-auto px-4">
          <div className="bg-[#FDFCF8] rounded-lg p-6 md:p-8 border border-black/5 shadow-sm relative text-center">
            
            {/* Animated Tick Icon Bubble */}
            <div className="h-14 w-14 bg-emerald-700 text-[#FDFCF8] rounded-full mx-auto flex items-center justify-center text-2xl shadow-sm mb-6 animate-pulse">
              ✓
            </div>

            <h3 className="font-serif text-2xl md:text-3xl font-semibold text-[#111111] leading-tight">আলহামদুলিল্লাহ্‌!</h3>
            <p className="text-emerald-700 font-bold text-xs uppercase tracking-widest mt-1">আপনার অর্ডারটি সফলভাবে গ্রহণ করা হয়েছে।</p>
            
            <p className="text-xs text-gray-400 mt-4 leading-relaxed font-light px-4">
              স্বল্প সময়ের মধ্যে আমাদের কাস্টমার রিলেশন টিম অর্ডার কনফার্ম করতে ও ডেলিভারির সময় নির্ধারণ করতে আপনার মোবাইল নাম্বারে কল করবে। দয়া করে ফোনটি সাথে রাখুন।
            </p>

            {/* Custom generated receipt card item */}
            <div className="mt-8 bg-[#F5F1E6] rounded-lg p-6 text-left border border-black/5 font-sans text-xs flex flex-col gap-3.5 select-none text-gray-600">
              <div className="flex justify-between border-b border-black/5 pb-2">
                <span className="font-semibold text-gray-400">অর্ডার আইডি:</span>
                <span className="font-bold text-gray-800 font-mono tracking-wider">{successOrder.orderId}</span>
              </div>
              <div className="flex justify-between border-b border-black/5 pb-2">
                <span className="font-semibold text-gray-400">গ্রাহকের নাম:</span>
                <span className="font-bold text-gray-800">{successOrder.customerName}</span>
              </div>
              <div className="flex justify-between border-b border-black/5 pb-2">
                <span className="font-semibold text-gray-400">মোবাইল নম্বর:</span>
                <span className="font-bold text-gray-800 font-mono">{successOrder.phone}</span>
              </div>
              <div className="flex justify-between border-b border-black/5 pb-2">
                <span className="font-semibold text-gray-400">পণ্যসমূহ:</span>
                <span className="font-bold text-gray-800 max-w-[240px] text-right line-clamp-2">{successOrder.productName}</span>
              </div>
              <div className="flex justify-between border-b border-black/5 pb-2">
                <span className="font-semibold text-gray-400">ডেলিভারি চার্জ:</span>
                <span className="font-bold text-emerald-800">
                  {successOrder.deliveryCharge === 0 ? "৳০ (ফ্রি)" : `৳${successOrder.deliveryCharge}`}
                </span>
              </div>
              <div className="flex justify-between border-b border-black/5 pb-2">
                <span className="font-semibold text-gray-400">পেমেন্ট মেথড:</span>
                <span className="font-bold text-[#1B3022] bg-[#1B3022]/10 px-2.5 py-0.5 rounded text-[10px] uppercase tracking-wider">{successOrder.paymentMethod}</span>
              </div>
              <div className="flex justify-between pt-2">
                <span className="font-bold text-gray-900 text-sm">সর্বমোট পরিশোধযোগ্য:</span>
                <span className="font-bold text-gray-900 text-base font-mono">৳{successOrder.totalPrice}</span>
              </div>
            </div>

            {/* Support Actions and Reset Checkout */}
            <div className="mt-8 flex flex-col gap-3">
              <a
                href={`https://wa.me/8801700000000?text=আসসালামু%20আলাইকুম।%20আমি%20একটি%20মধু%20অর্ডার%20করেছি।%20অর্ডার%20আইডি:%20${successOrder.orderId}`}
                target="_blank"
                rel="noreferrer"
                className="w-full py-3.5 bg-emerald-700 hover:bg-emerald-800 text-white font-sans font-bold text-xs md:text-sm rounded-lg shadow-xs transition-colors flex items-center justify-center gap-1.5 cursor-pointer uppercase tracking-wider"
              >
                <span>হোয়াটসঅ্যাপে দ্রুত নক করুন</span>
              </a>

              <button
                onClick={handleResetCheckout}
                className="w-full py-3 bg-[#FDFCF8] hover:bg-[#F5F1E6] text-gray-800 border border-black/10 font-serif font-bold text-[10px] uppercase tracking-widest rounded-lg transition-colors cursor-pointer h-10"
              >
                <span>নতুনভাবে অর্ডার করুন</span>
              </button>
            </div>

          </div>
        </div>
      </div>
    );
  }

  return (
    <section id="checkout-section" className="py-20 bg-[#FDFCF8] relative font-sans">
      <span className="hidden">Pure Honey BD Ordering Portal Form</span>
      <div className="max-w-7xl mx-auto px-4 md:px-6 lg:px-8">
        
        {/* Section Title */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="inline-flex items-center gap-1.5 bg-[#1B3022]/10 text-[#1B3022] px-4 py-1.5 rounded-full text-[10px] font-bold uppercase tracking-[0.2em] mb-3 select-none">
            <span>🛒</span> সহজ এক-ধাপের কুইক চেকআউট
          </div>
          <h2 className="font-serif text-3xl md:text-4xl text-[#111111] font-semibold tracking-tight leading-tight">
            অর্ডার ফর্মটি পূরণ করুন
          </h2>
          <div className="h-[1.5px] w-24 bg-[#D4AF37] mx-auto mt-4"></div>
          <p className="font-sans text-sm text-gray-500 mt-5 leading-relaxed font-light">
            কোনো অগ্রিম পেমেন্ট ছাড়াই সারা বাংলাদেশে ক্যাশ অন ডেলিভারিতে খাঁটি মধু অর্ডার করুন। অর্ডার পেতে নিচের ফর্মটি সঠিকভাবে সম্পন্ন করুন।
          </p>
        </div>

        {/* Layout Partition: Left is Cart Recap review, Right is checkout Inputs Form */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-start max-w-5xl mx-auto">
          
          {/* LEFT: CART RECAP (5 columns) */}
          <div className="lg:col-span-5 bg-[#F5F1E6] p-6 rounded-lg border border-black/5 shadow-xs">
            <h3 className="font-serif text-base md:text-lg font-bold text-[#111111] pb-3 border-b border-black/5 flex items-center justify-between text-left">
              <span>অর্ডারকৃত মধু সমূহ:</span>
              <span className="text-[10px] font-bold uppercase tracking-wider bg-[#1B3022]/10 text-[#1B3022] px-2.5 py-0.5 rounded">{totalQty} পিস</span>
            </h3>

            {cartItems.length === 0 ? (
              <div className="py-12 flex flex-col items-center text-center justify-center select-none text-gray-400">
                <ShoppingBag size={44} strokeWidth={1} />
                <p className="text-xs font-light text-gray-500 mt-3">অর্ডার করার জন্য কার্টে কোনো মধু যোগ করা নেই।</p>
                <a href="#products" className="text-xs text-[#D4AF37] font-bold mt-4 underline hover:text-amber-800">উপরে গিয়ে যেকোনো মধু অর্ডার করুন</a>
              </div>
            ) : (
              <div className="mt-4 flex flex-col gap-4 max-h-[280px] overflow-y-auto pr-1">
                {cartItems.map((item, idx) => (
                  <div key={idx} className="flex gap-3 pb-3 border-b border-black/5 items-center justify-between text-left">
                    <img 
                      src={item.product.image} 
                      alt={item.product.name} 
                      className="w-12 h-12 object-cover rounded border border-black/5"
                    />
                    <div className="flex-1 min-w-0">
                      <h4 className="font-bold text-xs truncate text-gray-900">{item.product.name}</h4>
                      <span className="text-[9px] text-[#D4AF37] bg-[#FDFCF8] border border-black/5 px-1.5 py-0.5 rounded mt-1 inline-block font-bold">
                        ওজন: {item.selectedWeight}
                      </span>
                    </div>
                    <div className="text-right flex flex-col justify-center">
                      <span className="font-bold font-mono text-xs text-gray-900">৳{item.selectedPrice * item.quantity}</span>
                      <span className="text-[9px] text-gray-400 mt-1">({item.quantity} পিস)</span>
                      <button 
                        onClick={() => onRemoveFromCart(idx)}
                        className="text-[10px] text-red-700 font-semibold hover:underline mt-1 text-right cursor-pointer"
                      >
                        বাদ দিন
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}

            {/* Calculations summaries */}
            {cartItems.length > 0 && (
              <div className="mt-6 pt-4 border-t border-black/5 flex flex-col gap-3 font-sans text-xs text-gray-500 select-none">
                
                {/* Shipping locations toggles */}
                <div className="bg-[#1B3022]/5 rounded-lg p-4 border border-black/5 text-left mb-2">
                  <span className="text-[9px] text-[#1B3022] font-extrabold uppercase tracking-widest block mb-2">ডেলিভারি এরিয়া সিলেক্ট করুন:</span>
                  <div className="flex gap-2">
                    <button
                      onClick={() => setShippingLocation('inside-dhaka')}
                      className={`flex-1 py-1.5 px-3 rounded text-[10px] uppercase font-bold tracking-wider border text-center transition-all cursor-pointer ${
                        shippingLocation === 'inside-dhaka'
                          ? 'bg-[#1B3022] text-[#FDFCF8] border-[#1B3022]'
                          : 'bg-[#FDFCF8] text-gray-600 border-black/10 font-normal'
                      }`}
                    >
                      ঢাকার ভেতরে (৳৬০)
                    </button>
                    <button
                      onClick={() => setShippingLocation('outside-dhaka')}
                      className={`flex-1 py-1.5 px-3 rounded text-[10px] uppercase font-bold tracking-wider border text-center transition-all cursor-pointer ${
                        shippingLocation === 'outside-dhaka'
                          ? 'bg-[#1B3022] text-[#FDFCF8] border-[#1B3022]'
                          : 'bg-[#FDFCF8] text-gray-600 border-black/10 font-normal'
                      }`}
                    >
                      ঢাকার বাইরে (৳১৩০)
                    </button>
                  </div>
                </div>

                <div className="flex justify-between border-b border-black/5 pb-2">
                  <span className="font-semibold text-gray-400">সাব-টোটাল মূল্য:</span>
                  <span className="font-bold text-gray-800 font-mono">৳{cartSubtotal}</span>
                </div>
                
                <div className="flex justify-between border-b border-black/5 pb-2 items-center">
                  <span className="font-semibold text-gray-400">ডেলিভারি চার্জ:</span>
                  <span className="font-bold">
                    {deliveryCharge === 0 ? (
                      <span className="text-emerald-700 flex items-center gap-1">
                        <span className="text-[10px] bg-emerald-100 text-emerald-800 px-1.5 py-0.5 rounded font-bold uppercase tracking-wider">অফার</span>
                        <span>৳০ (ফ্রি কুরিয়ার)</span>
                      </span>
                    ) : (
                      <span className="text-gray-800 font-mono">৳{deliveryCharge}</span>
                    )}
                  </span>
                </div>

                {isEligibleForFreeShipping && (
                  <div className="text-[10px] text-emerald-800 font-light text-left bg-emerald-50 px-2.5 py-1.5 rounded border border-emerald-100 flex items-center gap-1.5">
                    <span className="h-1.5 w-1.5 rounded-full bg-emerald-700 animate-pulse"></span>
                    <span>অভিনন্দন! আপনার বিলে কুরিয়ার চার্জ সম্পূর্ণ মওকুফ করা হয়েছে।</span>
                  </div>
                )}

                <div className="flex justify-between items-baseline pt-2">
                  <span className="font-bold text-gray-955 text-sm">সর্বমোট পরিশোধযোগ্য:</span>
                  <span className="font-serif font-bold text-gray-900 text-lg md:text-xl font-mono leading-none">৳{orderTotalPrice}</span>
                </div>
              </div>
            )}
          </div>

          {/* RIGHT: SHIPPING INPUTS FORM (7 columns) */}
          <div id="checkout-form-container" className="lg:col-span-7 bg-[#FDFCF8] p-6 md:p-8 rounded-lg border border-black/5 shadow-xs text-left">
            <h3 className="font-serif text-lg md:text-xl font-bold text-[#111111] pb-3 border-b border-black/5 flex items-center gap-1.5">
              <span>🏠</span> সঠিক ঠিকানা ও পেমেন্ট বিবরণ লিখুন:
            </h3>

            {errorMessage && (
              <div className="mt-4 bg-red-50 text-red-700 text-xs font-semibold p-4 rounded border border-red-200 flex items-center gap-2">
                <ShieldAlert size={16} className="text-red-500 shrink-0" />
                <span>{errorMessage}</span>
              </div>
            )}

            <form onSubmit={handleConfirmOrder} className="mt-6 flex flex-col gap-4 font-sans">
              
              {/* Customer Name */}
              <div className="flex flex-col text-left">
                <label className="text-xs font-semibold text-gray-700 mb-1.5">১. আপনার পূর্ণ নাম (কার্ডের নাম):</label>
                <input 
                  type="text"
                  placeholder="যেমন: মোঃ সাকিব হাসান"
                  value={customerName}
                  onChange={(e) => setCustomerName(e.target.value)}
                  className={`border ${fieldErrors.customerName ? 'border-red-500 focus:ring-red-400' : 'border-black/10 focus:border-[#D4AF37] focus:ring-1 focus:ring-[#D4AF37]'} rounded-lg bg-black/[0.01] p-3 text-xs md:text-sm focus:outline-none transition-all font-light`}
                  disabled={isSubmitting || cartItems.length === 0}
                />
                {fieldErrors.customerName && <span className="text-[10px] text-red-700 font-semibold mt-1">{fieldErrors.customerName}</span>}
              </div>

              {/* Mobile Phone check Number */}
              <div className="flex flex-col text-left">
                <label className="text-xs font-semibold text-gray-700 mb-1.5">২. মোবাইল নাম্বার (যা সচল আছে):</label>
                <input 
                  type="text"
                  placeholder="যেমন: 017XXXXXXXX (অবশ্যই ১১ ডিজিট)"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  className={`border ${fieldErrors.phone ? 'border-red-500 focus:ring-red-400' : 'border-black/10 focus:border-[#D4AF37] focus:ring-1 focus:ring-[#D4AF37]'} rounded-lg bg-black/[0.01] p-3 text-xs md:text-sm focus:outline-none transition-all font-mono font-light`}
                  maxLength={11}
                  disabled={isSubmitting || cartItems.length === 0}
                />
                {fieldErrors.phone && <span className="text-[10px] text-red-700 font-semibold mt-1">{fieldErrors.phone}</span>}
                <span className="text-[10px] text-gray-400 font-sans mt-1 font-light">অর্ডার নিশ্চিত করতে কুরিয়ার টিম বা আমাদের প্রতিনিধি আপনার এই নাম্বারে ফোন করবে।</span>
              </div>

              {/* Delivery Full Address */}
              <div className="flex flex-col text-left">
                <label className="text-xs font-semibold text-gray-700 mb-1.5">৩. পূর্ণাঙ্গ ঠিকানা (জেলা ও উপজেলা উল্লেখ করুন):</label>
                <textarea 
                  placeholder="যেমন: বাসা নং-২৩, রোড নং-০৪, ব্লক-ডি, উত্তরা, ঢাকা"
                  value={address}
                  onChange={(e) => setAddress(e.target.value)}
                  className={`border ${fieldErrors.address ? 'border-red-500 focus:ring-red-400' : 'border-black/10 focus:border-[#D4AF37] focus:ring-1 focus:ring-[#D4AF37]'} rounded-lg bg-black/[0.01] p-3 text-xs md:text-sm focus:outline-none transition-all min-h-[90px] font-light`}
                  disabled={isSubmitting || cartItems.length === 0}
                />
                {fieldErrors.address && <span className="text-[10px] text-red-700 font-semibold mt-1">{fieldErrors.address}</span>}
              </div>

              {/* Elegant Payment select system */}
              <div className="flex flex-col text-left select-none">
                <label className="text-xs font-semibold text-gray-700 mb-2">৪. পেমেন্ট মেথড বেছে নিন:</label>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-2.5">
                  {[
                    { id: PaymentMethod.COD, label: 'ক্যাশ অন ডেলিভারি (COD)', icon: '📦' },
                    { id: PaymentMethod.bkash, label: 'bKash (বিকাশ)', icon: '💸' },
                    { id: PaymentMethod.Nagad, label: 'Nagad (নগদ)', icon: '💰' },
                    { id: PaymentMethod.Rocket, label: 'Rocket (রকেট)', icon: '🚀' }
                  ].map((m) => (
                    <button
                      key={m.id}
                      type="button"
                      onClick={() => setSelectedPayment(m.id)}
                      className={`py-2 px-3 rounded border text-xs font-bold flex flex-col items-center justify-center gap-1.5 transition-all text-center cursor-pointer h-16 ${
                        selectedPayment === m.id
                          ? 'bg-[#F5F1E6] text-[#1B3022] border-[#D4AF37] shadow-xs'
                          : 'bg-black/[0.01] text-gray-500 border-black/5 hover:border-black/10'
                      }`}
                      disabled={isSubmitting || cartItems.length === 0}
                    >
                      <span className="text-lg leading-none">{m.icon}</span>
                      <span className="text-[9px] md:text-2xs truncate font-bold max-w-full leading-tight uppercase tracking-wider">{m.label}</span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Instruction panels if online payments */}
              {selectedPayment !== PaymentMethod.COD && (
                <div className="bg-[#F5F1E6]/50 border border-black/5 rounded-lg p-4 text-xs text-gray-600 flex flex-col gap-3 mt-2 select-none">
                  <p className="font-semibold text-gray-950 flex items-center gap-1">
                    💸 পেমেন্ট করার নিয়মাবলী:
                  </p>
                  <p className="leading-relaxed font-light">
                    ১. আমাদের বিকাশ/নগদ/রকেট পার্সোনাল অ্যাকাউন্ট নাম্বার: <strong className="text-gray-900 font-mono select-all font-bold">+৮৮০১৭১২-৩৪৫৬৭৮</strong> এ ওর্ডারের সর্বমোট <strong className="text-gray-900 font-bold font-mono">৳{orderTotalPrice}</strong> টাকা সেন্ড মানি করুন। <br />
                    ২. সেন্ড মানি করা সম্পন্ন হলে হিসাব এবং ট্রানজেকশন আইডি নিচে লিখে নিশ্চিত করুন।
                  </p>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5 mt-2">
                    <div className="flex flex-col text-left">
                      <span className="font-bold text-[10px] text-gray-400 uppercase tracking-wider mb-1">প্রেরক নাম্বার (যে নাম্বার থেকে পাঠিয়েছেন):</span>
                      <input 
                        type="text"
                        placeholder="যেমন: 017XXXXXXXX"
                        value={paymentNumber}
                        onChange={(e) => setPaymentNumber(e.target.value)}
                        className="border border-black/10 rounded-lg bg-white p-2.5 text-xs font-mono focus:outline-none focus:ring-1 focus:ring-[#D4AF37] focus:border-[#D4AF37] h-9 font-light"
                        disabled={isSubmitting}
                      />
                    </div>
                    <div className="flex flex-col text-left">
                      <span className="font-bold text-[10px] text-gray-400 uppercase tracking-wider mb-1">লেনদেন ট্রানজেকশন আইডি (TxID):</span>
                      <input 
                        type="text"
                        placeholder="যেমন: AK89LKH789"
                        value={transactionId}
                        onChange={(e) => setTransactionId(e.target.value)}
                        className="border border-black/10 rounded-lg bg-white p-2.5 text-xs font-mono uppercase focus:outline-none focus:ring-1 focus:ring-[#D4AF37] focus:border-[#D4AF37] h-9 font-light"
                        disabled={isSubmitting}
                      />
                    </div>
                  </div>
                </div>
              )}

              {/* Complete Confirmation Button */}
              <button
                type="submit"
                className={`w-full bg-[#111111] hover:bg-[#222222] border border-black text-[#FDFCF8] font-bold text-[11px] uppercase tracking-widest py-4 px-6 rounded-lg shadow-sm transition-all cursor-pointer flex items-center justify-center gap-2 h-14 mt-6 leading-none ${
                  cartItems.length === 0 ? 'opacity-50 cursor-not-allowed pointer-events-none' : ''
                }`}
                disabled={isSubmitting || cartItems.length === 0}
              >
                {isSubmitting ? (
                  <>
                    <Loader size={16} className="animate-spin text-white" />
                    <span>অর্ডার প্রসেস হচ্ছে...</span>
                  </>
                ) : (
                  <>
                    <Check size={16} className="text-[#FDFCF8]" />
                    <span>কনফার্ম অর্ডার করুন (৳{orderTotalPrice})</span>
                  </>
                )}
              </button>

            </form>
          </div>

        </div>

      </div>
    </section>
  );
}
