import { useState, useEffect } from 'react';
import { TESTIMONIALS } from '../data';
import { Quote, Star, CheckCircle, ChevronLeft, ChevronRight, User } from 'lucide-react';

export default function ReviewsSection() {
  const [activeIndex, setActiveIndex] = useState(0);
  const [filterVerified, setFilterVerified] = useState(false);

  const list = filterVerified ? TESTIMONIALS.filter(t => t.verified) : TESTIMONIALS;

  useEffect(() => {
    const timer = setInterval(() => {
      setActiveIndex((prev) => (prev + 1) % list.length);
    }, 6000);
    return () => clearInterval(timer);
  }, [list.length]);

  const handleNext = () => {
    setActiveIndex((prev) => (prev + 1) % list.length);
  };

  const handlePrev = () => {
    setActiveIndex((prev) => (prev - 1 + list.length) % list.length);
  };

  return (
    <section id="reviews" className="py-20 bg-[#F5F1E6] relative overflow-hidden">
      <span className="hidden">Pure Honey BD Customer Reviews and Testimonials</span>
      
      {/* Absolute decorative watermark quote illustration */}
      <div className="absolute top-[10%] left-[5%] text-[180px] font-serif text-[#D4AF37]/5 select-none pointer-events-none shrink-0 leading-none">
        “
      </div>
      <div className="absolute bottom-[5%] right-[5%] text-[180px] font-serif text-[#D4AF37]/5 select-none pointer-events-none shrink-0 leading-none">
        ”
      </div>

      <div className="max-w-7xl mx-auto px-4 md:px-6 lg:px-8 relative z-10">
        
        {/* Section Heading */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="inline-flex items-center gap-1.5 bg-[#1B3022]/10 text-[#1B3022] px-4 py-1.5 rounded-full text-[10px] font-bold uppercase tracking-[0.2em] mb-3 select-none">
            <span>❤</span> গ্রাহকের ভালোবাসার স্বীকৃতি
          </div>
          <h2 className="font-serif text-3xl md:text-4xl lg:text-5xl text-[#111111] font-semibold tracking-tight">
            আমাদের ওপর গ্রাহকদের সন্তুষ্টি
          </h2>
          <div className="h-[1.5px] w-24 bg-[#D4AF37] mx-auto mt-4"></div>
          <p className="font-sans text-sm text-gray-400 mt-5 leading-relaxed font-light">
            শত শত সুখী পরিবার তাদের নিত্যদিনের পুষ্টির চাহিদায় আমাদের মধু নিয়মিত ব্যবহার করছেন। গ্রাহকদের পাঠানো কিছু প্রকৃত ও ভেরিফাইড রিভিউ নিচে তুলে ধরা হলো।
          </p>
        </div>

        {/* Dynamic Reviews Wrapper with glassmorphic cards */}
        <div className="max-w-3xl mx-auto relative px-4 select-none">
          
          <div className="bg-[#FDFCF8] rounded-lg p-8 md:p-12 border border-black/5 shadow-sm transition-all duration-300 relative flex flex-col justify-between overflow-hidden">
            
            {/* Top double quotes icon */}
            <div className="flex justify-between items-start mb-6">
              <div className="h-10 w-10 bg-[#FAF1DF] text-[#D4AF37] rounded flex items-center justify-center">
                <Quote size={20} fill="currentColor" />
              </div>
              <div className="text-xs text-gray-400 font-medium">
                {list[activeIndex].date}
              </div>
            </div>

            {/* Comment Text Content */}
            <p className="font-sans text-sm md:text-base text-gray-700 leading-relaxed font-medium text-left min-h-[100px]">
              &quot;{list[activeIndex].comment}&quot;
            </p>

            <hr className="my-6 border-black/5" />

            {/* Buyer Bio Profile Information */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div className="flex items-center gap-3">
                <img 
                  src={list[activeIndex].avatar} 
                  alt={list[activeIndex].name} 
                  className="w-12 h-12 rounded-full border border-black/5 object-cover"
                  referrerPolicy="no-referrer"
                />
                <div className="text-left flex flex-col">
                  <span className="font-serif font-black text-sm md:text-base text-gray-950 flex items-center gap-1.5 leading-snug">
                    {list[activeIndex].name}
                    {list[activeIndex].verified && (
                      <span className="text-emerald-700 inline-flex items-center" title="Verified Purchase">
                        <CheckCircle size={14} fill="currentColor" className="text-white" />
                      </span>
                    )}
                  </span>
                  <span className="text-xs text-gray-400 leading-none mt-1 font-semibold">{list[activeIndex].location}</span>
                </div>
              </div>

              {/* Sub Bought specification */}
              <div className="flex flex-col items-start sm:items-end text-left sm:text-right select-none">
                <div className="flex items-center gap-0.5 text-[#D4AF37] mb-1">
                  {Array.from({ length: list[activeIndex].rating }).map((_, idx) => (
                    <Star key={idx} size={14} fill="currentColor" className="stroke-none" />
                  ))}
                </div>
                <span className="text-[10px] text-[#1B3022] font-semibold bg-[#FAF1DF] px-3 py-1 rounded border border-black/5">
                  ক্রয়কৃত: {list[activeIndex].productBought}
                </span>
              </div>
            </div>

          </div>

          {/* Left Arrow Controls button */}
          <button
            onClick={handlePrev}
            className="absolute top-1/2 -left-3 md:-left-12 -translate-y-1/2 p-2.5 rounded bg-[#FDFCF8] hover:bg-neutral-50 text-gray-600 hover:text-[#D4AF37] border border-black/10 shadow-sm transition-transform active:scale-95 cursor-pointer"
          >
            <ChevronLeft size={20} />
          </button>

          {/* Right Arrow Controls button */}
          <button
            onClick={handleNext}
            className="absolute top-1/2 -right-3 md:-right-12 -translate-y-1/2 p-2.5 rounded bg-[#FDFCF8] hover:bg-neutral-50 text-gray-600 hover:text-[#D4AF37] border border-black/10 shadow-sm transition-transform active:scale-95 cursor-pointer"
          >
            <ChevronRight size={20} />
          </button>

          {/* Interactive slider micro dots navigation indicators */}
          <div className="flex justify-center gap-2 mt-6">
            {list.map((_, idx) => (
              <button
                key={idx}
                onClick={() => setActiveIndex(idx)}
                className={`h-1.5 transition-all cursor-pointer ${
                  activeIndex === idx ? 'w-8 bg-[#111111]' : 'w-1.5 bg-gray-300'
                }`}
              ></button>
            ))}
          </div>

        </div>

        {/* Video / Trust badge banner */}
        <div className="mt-12 text-center text-xs text-gray-400 select-none">
          🛡 আপনার রিভিউ আমাদের কাছে অত্যন্ত সুবর্ণ। যেকোনো মন্তব্যে আমাদের সেবা উন্নত করে তুলি।
        </div>

      </div>
    </section>
  );
}
