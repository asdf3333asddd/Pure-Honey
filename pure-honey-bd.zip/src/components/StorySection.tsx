import { useState } from 'react';
import { HARVEST_PROCESS_IMG, STORIES_STEPS } from '../data';
import { Play, Sparkles, X, Award, Map, Users, Target } from 'lucide-react';

export default function StorySection() {
  const [isVideoOpen, setIsVideoOpen] = useState(false);

  // Stats Counters
  const stats = [
    { value: "৫,০০০+", label: "সুখী গ্রাহক", desc: "সারা বাংলাদেশে নিয়মিত ক্রেতা" },
    { value: "১০,০০০+", label: "সফল ডেলিভারি", desc: "দ্রুত ও নিরাপদ হোম ডেলিভারি" },
    { value: "১০০+", label: "বিশ্বস্ত মৌয়াল ও খামারি", desc: "ন্যায্য মজুরি ও প্রত্যক্ষ সম্পর্ক" },
    { value: "৭+ বছর", label: "সক্রিয় অভিজ্ঞতা", desc: "বিশুদ্ধতা রক্ষার দীর্ঘ যাত্রা" }
  ];

  return (
    <section id="story" className="py-20 bg-[#FDFCF8] relative overflow-hidden">
      <span className="hidden">Pure Honey BD Brand Story and Natural Extraction</span>
      
      {/* Radial soft ambient glow */}
      <div className="absolute top-[30%] left-[-10%] w-[500px] h-[500px] bg-[#D4AF37]/5 rounded-full blur-3xl pointer-events-none"></div>

      <div className="max-w-7xl mx-auto px-4 md:px-6 lg:px-8">
        
        {/* Split grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          
          {/* Left: Brand Story & Step Progression */}
          <div className="lg:col-span-7 text-left">
            <div className="inline-flex items-center gap-1.5 bg-[#1B3022]/10 text-[#1B3022] px-4 py-1.5 rounded-full text-[10px] font-bold uppercase tracking-[0.2em] mb-4">
              <Sparkles size={11} className="text-[#D4AF37]" />
              <span>আমাদের সংগ্রহ প্রক্রিয়ার পেছনের গল্প</span>
            </div>
            
            <h2 className="font-serif text-3xl md:text-4xl lg:text-5xl text-[#111111] font-semibold tracking-tight">
              গহীন জঙ্গল থেকে ড্রপ বাই ড্রপ <br />
              <span className="text-[#1B3022] font-bold">খাঁটি মধুর নিশ্চয়তা</span>
            </h2>
            
            <p className="font-sans text-sm text-gray-500 mt-5 leading-relaxed font-light">
              &apos;Pure Honey BD&apos; এর যাত্রা শুরু হয়েছিল একটি সৎ প্রতিজ্ঞা নিয়ে—বাংলাদেশের মানুষকে শতভাগ সুপার অর্গানিক আদিম ও প্রাকৃতিক মধুর চিরন্তন স্বাদ ফিরিয়ে দেওয়া। আমরা কৃত্রিম উপায়ে উৎপাদিত বা কেমিক্যাল ফিল্টার করা মধুকে সরাসরি বর্জন করে মৌয়াল ও চাষিদের দিয়ে বিশুদ্ধ মধু বোতলজাত করি।
            </p>

            {/* Horizontal timeline steps list */}
            <div className="mt-8 flex flex-col gap-6">
              {STORIES_STEPS.map((step, index) => (
                <div key={index} className="flex gap-4 items-start group select-none">
                  {/* Step counter button bubble */}
                  <div className="h-10 w-10 shrink-0 bg-[#1B3022]/5 text-[#1B3022] font-display font-extrabold text-sm rounded-lg flex items-center justify-center border border-[#1B3022]/10 group-hover:bg-[#1B3022] group-hover:text-white transition-all">
                    {step.step}
                  </div>
                  <div className="flex flex-col">
                    <h4 className="font-serif font-bold text-base text-[#111111]">{step.title}</h4>
                    <p className="text-xs md:text-sm text-gray-400 mt-1 leading-relaxed font-light">{step.desc}</p>
                  </div>
                </div>
              ))}
            </div>

          </div>

          {/* Right: Embedded Simulated Cinematic Video with Stats overlays */}
          <div className="lg:col-span-5 flex flex-col justify-center items-center">
            
            {/* Visual Cinematic block wrapper */}
            <div className="relative w-full max-w-[440px] aspect-[4/5] sm:aspect-square md:aspect-[3/4] rounded-lg overflow-hidden shadow-xl border border-black/5 group">
              
              {/* Backing generated harvesting photo */}
              <img 
                src={HARVEST_PROCESS_IMG} 
                alt="Organic honey extraction by local farmers in Bangladesh" 
                className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-102"
                referrerPolicy="no-referrer"
              />

              {/* Darkening elegant overlay gradient */}
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/30 to-black/35"></div>

              {/* Bottom video description tag */}
              <div className="absolute top-6 left-6 text-white text-[10px] font-bold uppercase tracking-widest flex items-center gap-1.5 opacity-80">
                <span className="animate-pulse h-1.5 w-1.5 rounded-full bg-[#D4AF37]"></span>
                <span>AUTHENTIC HARVESTING</span>
              </div>

              {/* Middle Play Button with custom ripple effect */}
              <div className="absolute inset-0 flex items-center justify-center">
                <button
                  onClick={() => setIsVideoOpen(true)}
                  className="relative h-14 w-14 rounded-full bg-[#D4AF37] text-white flex items-center justify-center shadow-lg hover:scale-105 active:scale-95 transition-all cursor-pointer group"
                >
                  {/* Decorative bouncing concentric circles */}
                  <span className="absolute inset-0 rounded-full bg-[#D4AF37] opacity-30 animate-ping -z-10"></span>
                  
                  <Play size={18} fill="currentColor" className="ml-1 text-white" />
                </button>
              </div>

              {/* Bottom video description tag */}
              <div className="absolute bottom-6 left-6 right-6 text-left">
                <h4 className="font-serif font-bold text-sm text-white">খামারের ভিডিও চিত্রমালা</h4>
                <p className="text-[10px] text-gray-300 mt-1 leading-normal font-light">দেখে নিন কীভাবে সুন্দরবন ও আমাদের অন্যান্য খামার থেকে নিখুঁত পরিচ্ছন্ন উপায়ে মধু সংগ্রহ করা হয়।</p>
              </div>

            </div>

          </div>

        </div>

        {/* Stats Section Bento style box */}
        <div className="mt-20 grid grid-cols-2 lg:grid-cols-4 gap-4 bg-[#F5F1E6] p-6 md:p-8 rounded-lg border border-black/5">
          {stats.map((stat, i) => (
            <div key={i} className="flex flex-col items-center justify-center text-center p-5 rounded-lg bg-[#FDFCF8] border border-black/5 select-none hover:bg-white transition-all shadow-sm">
              <span className="font-serif font-extrabold text-2xl text-[#1B3022] tracking-tight">{stat.value}</span>
              <span className="font-serif font-bold text-xs text-gray-800 mt-1.5">{stat.label}</span>
              <span className="text-[10px] text-gray-400 mt-1 max-w-[160px] leading-tight font-light">{stat.desc}</span>
            </div>
          ))}
        </div>

      </div>

      {/* Video Modal Portal simulation */}
      {isVideoOpen && (
        <div className="fixed inset-0 z-50 overflow-y-auto flex items-center justify-center p-4">
          <div onClick={() => setIsVideoOpen(false)} className="fixed inset-0 bg-black/90 backdrop-blur-sm"></div>
          <div className="bg-charcoal rounded-2xl w-full max-w-3xl aspect-video overflow-hidden shadow-2xl relative border border-gray-800 z-10 flex flex-col justify-center items-center">
            
            <button
              onClick={() => setIsVideoOpen(false)}
              className="absolute top-4 right-4 p-2 rounded-xl bg-black/30 hover:bg-black/50 text-white z-20"
            >
              <X size={18} />
            </button>

            {/* Simulated YouTube video trailer / Organic honey doc trailer */}
            <iframe 
              className="w-full h-full"
              src="https://www.youtube.com/embed/dQw4w9WgXcQ?autoplay=1" 
              title="Pure Honey BD Extraction Sourcing Story Video" 
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" 
              allowFullScreen
            ></iframe>
          </div>
        </div>
      )}

    </section>
  );
}
